﻿//using CrystalDecisions.CrystalReports.Engine;
//using CrystalDecisions.Shared;
using SAPbouiCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using Newtonsoft.Json;

namespace LMS
{
    class InternalRequestion
    {

        #region Variables
        SAPbouiCOM.Form frmIR;
        SAPbouiCOM.DBDataSource oDBDSHeader, oDBDSDetail;
        SAPbouiCOM.Matrix oMatrix;
        SAPbouiCOM.Column oColumn;
        SAPbouiCOM.Columns oColumns;
        string DeleteRowITEMUID = "";
        SAPbouiCOM.IForm IFrm;
        static string closeDocNum = "";
        static string closeUserName = "";
        static string closeDocType = "";


        #endregion
        public void LoadInternal()
        {
            try
            {
                GlobalVariables.oGFun.LoadXML(frmIR, GlobalVariables.IRID, GlobalVariables.IrXml);
                frmIR = EventHandler.oApplication.Forms.Item(GlobalVariables.IRID);
                oDBDSHeader = frmIR.DataSources.DBDataSources.Item("@AC_OIRT");
                oDBDSDetail = frmIR.DataSources.DBDataSources.Item("@AC_IRT1");
                oMatrix = frmIR.Items.Item("Matrix").Specific;
                //Reciving data from Api
                IFrm = EventHandler.oApplication.Forms.Item(GlobalVariables.IRID);

                this.InitForm();
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("Load : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
        }
        public void InitForm()
        {
            try
            {
                GC.Collect();
                frmIR.Freeze(true);
                frmIR.Mode = SAPbouiCOM.BoFormMode.fm_ADD_MODE;
                    oDBDSHeader.SetValue("DocNum", 0, GlobalVariables.oGFun.GetCodeGeneration("@AC_OIRT").ToString());
                    oDBDSHeader.SetValue("U_Status", 0, "O");
                    oDBDSHeader.SetValue("U_DocType", 0, "I");
                    oDBDSHeader.SetValue("U_Issuance", 0, "Normal");
                    //oDBDSHeader.SetValue("U_CDate", 0, DateTime.Now.ToString());
                    frmIR.Items.Item("t_DocNum").Enabled = false;
                    frmIR.Items.Item("t_Dept").Enabled = false;
                    frmIR.Items.Item("t_Status").Enabled = false;
                    frmIR.Items.Item("t_EmpName").Enabled = false;
                    frmIR.Items.Item("t_User").Enabled = false;
                    frmIR.Items.Item("333").Enabled = false;
                    oDBDSHeader.SetValue("CreateDate", 0, GlobalVariables.oGFun.GetServerDate());
                    oDBDSHeader.SetValue("U_PDate", 0, GlobalVariables.oGFun.GetServerDate());
                    GlobalVariables.oGFun.SetNewLine(oMatrix, oDBDSDetail);
                    frmIR.EnableMenu("1292", true);
                    frmIR.EnableMenu("774", false);
                    oMatrix.Item.Enabled = true;
                    //For Disable service description
                    oMatrix.CommonSetting.SetRowEditable(1, true);
                    itemClose();
                    oMatrix.Columns.Item("V_6").Editable = false;
                    oMatrix.Columns.Item("V_100").Editable = false;
                    oMatrix.AutoResizeColumns();
                    oMatrix.Columns.Item("V_10").Width = 300;
                    SAPbobsCOM.Recordset oRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    //Set Current user login Employee
                    string UserName = GlobalVariables.oCompany.UserName;
                    string query = string.Format(@"Select T0.[empID],T0.[firstName],T0.[lastName],T2.[Name] from OHEM T0  INNER JOIN
                         OUSR T1 ON T0.[userId] = T1.[USERID]
                         Inner join OUDP T2 on T0.[dept] = T2.[Code]
                          where T1.[USER_CODE] = '" + UserName + "'").Replace("[", "\"").Replace("]", "\"");
                    oRecord.DoQuery(query);
                    oDBDSHeader.SetValue("U_EmpCode", 0, oRecord.Fields.Item("empID").Value);
                    string FullName = oRecord.Fields.Item("firstName").Value + " " + oRecord.Fields.Item("lastName").Value;
                    oDBDSHeader.SetValue("U_EmpName", 0, FullName);
                    oDBDSHeader.SetValue("U_Dept", 0, oRecord.Fields.Item("Name").Value);
                    oDBDSHeader.SetValue("U_User", 0, GlobalVariables.oCompany.UserName);
                    oDBDSHeader.SetValue("U_CDate", 0, GlobalVariables.oGFun.GetServerDate());
                    GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "cfl_BusinessUni", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],2) = 'BU'").Replace("[", "\"").Replace("]", "\""));
                    GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "cfl_Location", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],1) = 'L'").Replace("[", "\"").Replace("]", "\""));

                    frmIR.Items.Item("t_EmpCode").Click();

                    frmIR.Freeze(false);
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.MessageBox(ex.Message);
                frmIR.Freeze(false);
            }
            finally
            {
            }
        }

        #region Validation


        //For Services Selection
        public void serClose()
        {
            try
            {
                frmIR.Freeze(true);
                oColumns = oMatrix.Columns;
                oColumn = oColumns.Item("V_11");
                oColumn.Visible = false;
                oColumn = oColumns.Item("V_6");
                oColumn.Visible = false;
                oColumn = oColumns.Item("V_100");
                oColumn.Visible = false;
                oColumn = oColumns.Item("V_10");
                oColumn.Visible = false;
                oColumn = oColumns.Item("t_serDes");
                oColumn.Visible = true;
                oColumn = oColumns.Item("6676");
                oColumn.Visible = true;
                oMatrix.AutoResizeColumns();
                frmIR.Freeze(false);
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("Load : " + ex.Message , SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
        }
        //For Services Items
        public void itemClose()
        {
            try
            {
                frmIR.Freeze(true);
                oColumns = oMatrix.Columns;
                oColumn = oColumns.Item("V_11");
                oColumn.Visible = true;
                oColumn = oColumns.Item("V_6"); 
                oColumn.Visible = true;
                oColumn = oColumns.Item("V_100");
                oColumn.Visible = true;
                oColumn = oColumns.Item("V_10");
                oColumn.Visible = true;
                oColumn = oColumns.Item("6676");
                oColumn.Visible = false;
                oColumn = oColumns.Item("t_serDes");
                oColumn.Visible = false;
                oMatrix.AutoResizeColumns();
                frmIR.Freeze(false);
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("Load : " + ex.Message + " Line No: " + ex.StackTrace, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
        }

        public bool ValidateAll()
        {
            bool functionReturnValue = false;
            try
            {
                if (frmIR.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE || frmIR.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE)
                {
                    if (((SAPbouiCOM.EditText)frmIR.Items.Item("t_PDate").Specific).Value == "")
                    {
                        EventHandler.oApplication.StatusBar.SetText("Postind Date is mandatory....", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        frmIR.Items.Item("t_PDate").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        return false;
                    }
                    if (((SAPbouiCOM.EditText)frmIR.Items.Item("t_EmpCode").Specific).Value == "")
                    {
                        EventHandler.oApplication.StatusBar.SetText("Employee code is manadatory... ", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        frmIR.Items.Item("t_EmpCode").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        return false;
                    }
                    if (((SAPbouiCOM.EditText)frmIR.Items.Item("t_Store").Specific).Value == "")
                    {
                        EventHandler.oApplication.StatusBar.SetText("Store is manadatory... ", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        frmIR.Items.Item("t_Store").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                        return false;
                    }

                    //For Matrix
                    for (int i = 0; i < oMatrix.RowCount - 1; i++)
                    {
                        string ItemCode = Convert.ToString(oMatrix.Columns.Item("V_11").Cells.Item(i + 1).Specific.Value);
                        string ItemDesc = Convert.ToString(oMatrix.Columns.Item("V_10").Cells.Item(i + 1).Specific.Value);
                        string SerDes = Convert.ToString(oMatrix.Columns.Item("t_serDes").Cells.Item(i + 1).Specific.Value);
                        //If Item Code was manually removed than show error
                        if(!string.IsNullOrEmpty(ItemDesc) && string.IsNullOrEmpty(ItemCode))
                        {
                            EventHandler.oApplication.StatusBar.SetText(("Kindly fill Item Number..."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            oMatrix.Columns.Item("V_11").Cells.Item(i + 1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                            return false;
                        }

                        if (!string.IsNullOrEmpty(ItemCode) || !string.IsNullOrEmpty(SerDes))
                        {
                            double Quantity = Convert.ToDouble(oMatrix.Columns.Item("V_8").Cells.Item(i + 1).Specific.Value);
                            double OpenQty = Convert.ToDouble(oMatrix.Columns.Item("V_100").Cells.Item(i + 1).Specific.Value);
                            string CurDate = Convert.ToString(oMatrix.Columns.Item("V_7").Cells.Item(i + 1).Specific.Value);
                            string BusUnit = Convert.ToString(oMatrix.Columns.Item("V_5").Cells.Item(i + 1).Specific.Value);
                            string Location = Convert.ToString(oMatrix.Columns.Item("V_4").Cells.Item(i + 1).Specific.Value);
                            string Depart = Convert.ToString(oMatrix.Columns.Item("V_3").Cells.Item(i + 1).Specific.Value);
                            string CostCen = Convert.ToString(oMatrix.Columns.Item("V_2").Cells.Item(i + 1).Specific.Value);
                            string Employee = Convert.ToString(oMatrix.Columns.Item("V_1").Cells.Item(i + 1).Specific.Value);
                            if (Quantity <= 0)
                            {
                                EventHandler.oApplication.StatusBar.SetText(("Quantity cannot be zero...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                oMatrix.Columns.Item("V_8").Cells.Item(i + 1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                return false;
                            }
                            if (OpenQty <= 0)
                            {
                                EventHandler.oApplication.StatusBar.SetText(("Open Quantity cannot be zero Kindly press TAB...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                oMatrix.Columns.Item("V_8").Cells.Item(i + 1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                return false;
                            }
                            SAPbouiCOM.ComboBox getType = (SAPbouiCOM.ComboBox)frmIR.Items.Item("50000").Specific;
                            string docT = getType.Value.ToString();
                            if(docT == "I")
                            {
                                if (string.IsNullOrEmpty(CurDate) || string.IsNullOrEmpty(BusUnit) || string.IsNullOrEmpty(Location) || string.IsNullOrEmpty(Depart) || string.IsNullOrEmpty(CostCen))
                                {
                                    EventHandler.oApplication.StatusBar.SetText(("Kindly fill mandatory fields...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    oMatrix.Columns.Item("V_7").Cells.Item(i + 1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                    return false;
                                }
                            }
                            else
                            {
                                if (string.IsNullOrEmpty(Depart))
                                {
                                    EventHandler.oApplication.StatusBar.SetText(("Kindly select Department...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                    oMatrix.Columns.Item("V_3").Cells.Item(i + 1).Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                    return false;
                                }
                            }
                        }
                    }
                }
                functionReturnValue = true;
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.MessageBox(ex.Message);
                functionReturnValue = false;
            }
            finally
            {
            }
            return functionReturnValue;
        }
        #endregion

        #region SAPEvents
        public void ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                //switch (pVal.CharPressed)
                //{
                //    //case 38:
                //    //    if (pVal.BeforeAction == false && pVal.Row != 1)
                //    //    {
                //    //        frmIR.Freeze(true);
                //    //        oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row - 1).Click(SAPbouiCOM.BoCellClickType.ct_Double);
                //    //        frmIR.Freeze(false);


                //    //    }
                //    //    break;

                //    //case 40:
                //    //    if (pVal.BeforeAction == false && pVal.Row != oMatrix.RowCount)
                //    //    {
                //    //        frmIR.Freeze(true);
                //    //        oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row + 1).Click(SAPbouiCOM.BoCellClickType.ct_Double);
                //    //        frmIR.Freeze(false);
                //    //    }
                //    //    break;
                //}
                switch (pVal.EventType)
                {
                    #region Choose_from_list
                    case SAPbouiCOM.BoEventTypes.et_CHOOSE_FROM_LIST:
                        try
                        {
                            SAPbobsCOM.Recordset oRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

                            SAPbouiCOM.ChooseFromListEvent cfle;
                            SAPbouiCOM.DataTable oDataTable;
                            cfle = (ChooseFromListEvent)pVal;
                            oDataTable = cfle.SelectedObjects;
                            if ((oDataTable != null) & pVal.BeforeAction == false)
                            {
                                switch (pVal.ItemUID)
                                {
                                    case "t_EmpCode":
                                        if (pVal.BeforeAction == false && frmIR.Mode != SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                                        {
                                            oDBDSHeader.SetValue("U_EmpCode", 0, oDataTable.GetValue("Code", 0));
                                            string Name = oDataTable.GetValue("firstName", 0) + " " + oDataTable.GetValue("lastName", 0);
                                            oDBDSHeader.SetValue("U_EmpName", 0, Name);
                                            string GetCusCode = oDataTable.GetValue("Code", 0);

                                            string query = string.Format("Select T1.[Name] from OHEM T0  INNER JOIN OUDP T1 ON T0.[dept] = T1.[Code] where T0.[Code] = '" + GetCusCode + "'").Replace("[", "\"").Replace("]", "\"");
                                            oRecord.DoQuery(query);
                                            string DepartName = Convert.ToString(oRecord.Fields.Item("Name").Value) ?? "";
                                            oDBDSHeader.SetValue("U_Dept", 0, DepartName);
                                        }
                                        break;
                                    case "334":
                                        if (pVal.BeforeAction == false && frmIR.Mode != SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                                        {
                                            oDBDSHeader.SetValue("U_BisUn", 0, oDataTable.GetValue("PrcCode", 0));
                                        }
                                        break;

                                    case "335":
                                        if (pVal.BeforeAction == false && frmIR.Mode != SAPbouiCOM.BoFormMode.fm_FIND_MODE)
                                        {
                                            oDBDSHeader.SetValue("U_Location", 0, oDataTable.GetValue("PrcCode", 0));
                                        }
                                        break;

                                    //Store CFL
                                    case "t_Store":
                                        if (pVal.BeforeAction == false)
                                        {
                                            oDBDSHeader.SetValue("U_Store", 0, oDataTable.GetValue("WhsCode", 0));
                                        }
                                        break;

                                    case "Matrix":
                                        switch (pVal.ColUID)
                                        {
                                            case "V_11":
                                                if (pVal.BeforeAction == false)
                                                {
                                                    //oMatrix.FlushToDataSource();
                                                    int Count = oDataTable.Rows.Count;
                                                    int Row = pVal.Row - 1;

                                                    if (Count > 1)
                                                    {
                                                        for (int i = 0; i <= Count - 1; i++)
                                                        {
                                                            oMatrix.FlushToDataSource();
                                                            oDBDSDetail.SetValue("U_ItemCode", Row + i, oDataTable.GetValue("ItemCode", i));
                                                            oDBDSDetail.SetValue("U_ItemDesc", Row + i, oDataTable.GetValue("ItemName", i));
                                                            int crrrow = pVal.Row - 1;
                                                            string ItemCode = oDataTable.GetValue("ItemCode", i);
                                                            if (!string.IsNullOrEmpty(ItemCode))
                                                            {
                                                                SAPbobsCOM.Recordset oLocRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                                                                string Location = ((SAPbouiCOM.EditText)frmIR.Items.Item("335").Specific).Value ?? "";
                                                                string BusinessUnit = ((SAPbouiCOM.EditText)frmIR.Items.Item("334").Specific).Value ?? "";
                                                                string LoctQuery = string.Format("Select [PrcName] from OPRC where [PrcCode] = '" + Location + "' ").Replace("[", "\"").Replace("]", "\"");
                                                                oLocRecord.DoQuery(LoctQuery);
                                                                string LoctName = Convert.ToString(oLocRecord.Fields.Item("PrcName").Value); string query = "";
                                                                if (!string.IsNullOrEmpty(Location))
                                                                {
                                                                    if(LoctName == "Karachi")
                                                                    {
                                                                        query = string.Format("Select (sum(T1.[OnHand]))Total,T0.[InvntryUom] from OITM T0 Inner Join OITW T1 on T0.[ItemCode] = T1.[ItemCode] inner Join OWHS T2 on T1.[WhsCode] = T2.[WhsCode] where T0.[ItemCode] = '" + ItemCode + "' and T2.[WhsName] LIKE '%%Karachi%%' Group by T0.[ItemCode],T0.[InvntryUom]").Replace("[", "\"").Replace("]", "\"");

                                                                    }
                                                                    else
                                                                    {
                                                                        query = string.Format("Select (sum(T1.[OnHand]))Total,T0.[InvntryUom] from OITM T0 Inner Join OITW T1 on T0.[ItemCode] = T1.[ItemCode] inner Join OWHS T2 on T1.[WhsCode] = T2.[WhsCode] where T0.[ItemCode] = '" + ItemCode + "' and T2.[WhsName] Not LIKE '%%Karachi%%' Group by T0.[ItemCode],T0.[InvntryUom]").Replace("[", "\"").Replace("]", "\"");

                                                                    }
                                                                    oRecord.DoQuery(query);
                                                                    double Qant = Convert.ToDouble(oRecord.Fields.Item("Total").Value);
                                                                   // string BPName = Convert.ToString(oRecord.Fields.Item("InvntryUom").Value);
                                                                    oDBDSDetail.SetValue("U_CStock", Row + i, Convert.ToString(Qant));
                                                                   // oDBDSDetail.SetValue("U_UOM", Row + i, Convert.ToString(BPName));
                                                                    query = string.Format("Select T0.[InvntryUom] from OITM T0  where T0.[ItemCode] = '" + ItemCode + "'").Replace("[", "\"").Replace("]", "\"");
                                                                    oRecord.DoQuery(query);
                                                                    string BPName = Convert.ToString(oRecord.Fields.Item("InvntryUom").Value);
                                                                    oDBDSDetail.SetValue("U_UOM", Row + i, Convert.ToString(BPName));
                                                                    oDBDSDetail.SetValue("U_RDate", Row + i, GlobalVariables.oGFun.GetServerDate());
                                                                }
                                                                else
                                                                {
                                                                    query = string.Format("Select T0.[InvntryUom] from OITM T0  where T0.[ItemCode] = '" + ItemCode + "'").Replace("[", "\"").Replace("]", "\"");
                                                                    oRecord.DoQuery(query);
                                                                    string BPName = Convert.ToString(oRecord.Fields.Item("InvntryUom").Value);
                                                                    oDBDSDetail.SetValue("U_UOM", Row + i, Convert.ToString(BPName));
                                                                    EventHandler.oApplication.StatusBar.SetText(("Kindly select Location in Top..."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                                    frmIR.Items.Item("335").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                                                    //EventHandler.oApplication.StatusBar.SetText(("Kindly select Location in Top..."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                                    // frmIR.Items.Item("335").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                                                }
                                                                //string query = string.Format("Select ([OnHand]+[OnOrder]-[IsCommited])Total,T1.[UgpName],T0.[SalUnitMsr],T0.[InvntryUom] from OITM T0 Inner Join OUGP T1 on T0.[UgpEntry] = T1.[UgpEntry] where [ItemCode] = '" + ItemCode + "'").Replace("[", "\"").Replace("]", "\"");
                                                                //oRecord.DoQuery(query);
                                                                //int Qant = Convert.ToInt32(oRecord.Fields.Item("Total").Value);
                                                                //string BPName = Convert.ToString(oRecord.Fields.Item("InvntryUom").Value);
                                                                //oDBDSDetail.SetValue("U_CStock", i, Convert.ToString(Qant));
                                                                //oDBDSDetail.SetValue("U_UOM", i, Convert.ToString(BPName));
                                                                //string Location = ((SAPbouiCOM.EditText)frmIR.Items.Item("335").Specific).Value ?? "";
                                                                //string BusinessUnit = ((SAPbouiCOM.EditText)frmIR.Items.Item("334").Specific).Value ?? "";
                                                                SAPbobsCOM.Recordset oRecord1 = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                                                                if (!string.IsNullOrEmpty(Location))
                                                                {
                                                                    string LocQuery = string.Format("Select [PrcName] from OPRC where [PrcCode] = '" + Location + "' ").Replace("[", "\"").Replace("]", "\"");
                                                                    oRecord1.DoQuery(LocQuery);
                                                                    string LocName = Convert.ToString(oRecord1.Fields.Item("PrcName").Value);
                                                                    oDBDSDetail.SetValue("U_Location", Row + i, Location);
                                                                    oDBDSDetail.SetValue("U_LocationName", Row + i, LocName);
                                                                    oDBDSDetail.SetValue("U_RDate", Row + i, GlobalVariables.oGFun.GetServerDate());
                                                                }
                                                                if (!string.IsNullOrEmpty(BusinessUnit))
                                                                {
                                                                    string BusiName = string.Format("Select [PrcName] from OPRC where [PrcCode] = '" + BusinessUnit + "' ").Replace("[", "\"").Replace("]", "\"");
                                                                    oRecord1.DoQuery(BusiName);
                                                                    string BUName = Convert.ToString(oRecord1.Fields.Item("PrcName").Value);
                                                                    oDBDSDetail.SetValue("U_BusUnit", Row + i, BusinessUnit);
                                                                    oDBDSDetail.SetValue("U_BusUnitName", Row + i, BUName);
                                                                    oDBDSDetail.SetValue("U_RDate", Row + i, GlobalVariables.oGFun.GetServerDate());
                                                                }
                                                            }

                                                            oDBDSDetail.SetValue("U_RDate", Row + i, GlobalVariables.oGFun.GetServerDate());
                                                            oMatrix.LoadFromDataSource();
                                                            GlobalVariables.oGFun.SetNewLine(oMatrix, oDBDSDetail, oMatrix.VisualRowCount, "V_11");
                                                            oMatrix.CommonSetting.SetRowEditable(pVal.Row + 1, true);
                                                            oMatrix.Columns.Item("V_6").Editable = false;
                                                            oMatrix.Columns.Item("V_100").Editable = false;
                                                            oMatrix.Columns.Item("V_10").Cells.Item(pVal.Row).Click();
                                                        }
                                                    }
                                                    else if (Count == 1)
                                                    {
                                                        oMatrix.FlushToDataSource();
                                                        oDBDSDetail.SetValue("U_ItemCode", pVal.Row - 1, oDataTable.GetValue("ItemCode", 0));
                                                        oDBDSDetail.SetValue("U_ItemDesc", pVal.Row - 1, oDataTable.GetValue("ItemName", 0));
                                                        string ItemCode = oDataTable.GetValue("ItemCode", 0);
                                                        if (!string.IsNullOrEmpty(ItemCode))
                                                        {
                                                            SAPbobsCOM.Recordset oLocRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                                                            string Location = ((SAPbouiCOM.EditText)frmIR.Items.Item("335").Specific).Value ?? "";
                                                            string BusinessUnit = ((SAPbouiCOM.EditText)frmIR.Items.Item("334").Specific).Value ?? "";
                                                            string LoctQuery = string.Format("Select [PrcName] from OPRC where [PrcCode] = '" + Location + "' ").Replace("[", "\"").Replace("]", "\"");
                                                            oLocRecord.DoQuery(LoctQuery);
                                                            string LoctName = Convert.ToString(oLocRecord.Fields.Item("PrcName").Value);string query = "";
                                                            if (!string.IsNullOrEmpty(Location))
                                                            {

                                                                if (LoctName == "Karachi")
                                                                {
                                                                    query = string.Format("Select (sum(T1.[OnHand]))Total,T0.[InvntryUom] from OITM T0 Inner Join OITW T1 on T0.[ItemCode] = T1.[ItemCode] inner Join OWHS T2 on T1.[WhsCode] = T2.[WhsCode] where T0.[ItemCode] = '" + ItemCode + "' and T2.[WhsName] LIKE '%%Karachi%%' Group by T0.[ItemCode],T0.[InvntryUom]").Replace("[", "\"").Replace("]", "\"");
                                                                }
                                                                else
                                                                {
                                                                    query = string.Format("Select (sum(T1.[OnHand]))Total,T0.[InvntryUom] from OITM T0 Inner Join OITW T1 on T0.[ItemCode] = T1.[ItemCode] inner Join OWHS T2 on T1.[WhsCode] = T2.[WhsCode] where T0.[ItemCode] = '" + ItemCode + "' and T2.[WhsName] Not LIKE '%%Karachi%%' Group by T0.[ItemCode],T0.[InvntryUom]").Replace("[", "\"").Replace("]", "\"");
                                                                }

                                                                //query = string.Format("Select (sum(T1.[OnHand]))Total,T0.[InvntryUom] from OITM T0 Inner Join OITW T1 on T0.[ItemCode] = T1.[ItemCode] inner Join OWHS T2 on T1.[WhsCode] = T2.[WhsCode] where T0.[ItemCode] = '" + ItemCode + "' and T2.[WhsName] LIKE '%%" + LoctName + "%%' Group by T0.[ItemCode],T0.[InvntryUom]").Replace("[", "\"").Replace("]", "\"");
                                                                oRecord.DoQuery(query);
                                                                double Qant = Convert.ToDouble(oRecord.Fields.Item("Total").Value);
                                                                string BPName = Convert.ToString(oRecord.Fields.Item("InvntryUom").Value);
                                                                oDBDSDetail.SetValue("U_CStock", pVal.Row - 1, Convert.ToString(Qant));
                                                                oDBDSDetail.SetValue("U_UOM", pVal.Row - 1, Convert.ToString(BPName));
                                                                oDBDSDetail.SetValue("U_RDate",pVal.Row -1, GlobalVariables.oGFun.GetServerDate());
                                                            }
                                                            else
                                                            {
                                                                query = string.Format("Select T0.[InvntryUom] from OITM T0  where T0.[ItemCode] = '"+ItemCode+"'").Replace("[", "\"").Replace("]", "\"");
                                                                oRecord.DoQuery(query);
                                                                string BPName = Convert.ToString(oRecord.Fields.Item("InvntryUom").Value);
                                                                oDBDSDetail.SetValue("U_UOM", pVal.Row - 1, Convert.ToString(BPName));
                                                                oDBDSDetail.SetValue("U_RDate", pVal.Row - 1, GlobalVariables.oGFun.GetServerDate());
                                                                EventHandler.oApplication.StatusBar.SetText(("Kindly select Location in Top..."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                                frmIR.Items.Item("335").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                                                            }
                                                            SAPbobsCOM.Recordset oRecord1 = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                                                            if (!string.IsNullOrEmpty(Location))
                                                            {
                                                                string LocQuery = string.Format("Select [PrcName] from OPRC where [PrcCode] = '"+Location+"' ").Replace("[", "\"").Replace("]", "\"");
                                                                oRecord1.DoQuery(LocQuery);
                                                                string LocName = Convert.ToString(oRecord1.Fields.Item("PrcName").Value);
                                                                oDBDSDetail.SetValue("U_Location", pVal.Row - 1, Location);
                                                                oDBDSDetail.SetValue("U_LocationName", pVal.Row - 1, LocName);
                                                                oDBDSDetail.SetValue("U_RDate", pVal.Row - 1, GlobalVariables.oGFun.GetServerDate());
                                                            }
                                                            if (!string.IsNullOrEmpty(BusinessUnit))
                                                            {
                                                                string BusiName = string.Format("Select [PrcName] from OPRC where [PrcCode] = '" + BusinessUnit + "' ").Replace("[", "\"").Replace("]", "\"");
                                                                oRecord1.DoQuery(BusiName);
                                                                string BUName = Convert.ToString(oRecord1.Fields.Item("PrcName").Value);
                                                                oDBDSDetail.SetValue("U_BusUnit", pVal.Row - 1, BusinessUnit);
                                                                oDBDSDetail.SetValue("U_BusUnitName", pVal.Row - 1, BUName);
                                                                oDBDSDetail.SetValue("U_RDate", pVal.Row - 1, GlobalVariables.oGFun.GetServerDate());
                                                            }
                                                        }
                                                        oMatrix.LoadFromDataSource();
                                                        GlobalVariables.oGFun.SetNewLine(oMatrix, oDBDSDetail);
                                                        oMatrix.CommonSetting.SetRowEditable(pVal.Row + 1, true);
                                                        oMatrix.Columns.Item("V_6").Editable = false;
                                                        oMatrix.Columns.Item("V_100").Editable = false;
                                                        oMatrix.Columns.Item("V_10").Cells.Item(pVal.Row).Click();
                                                    }
                                                }
                                                break;
                                            case "V_2":
                                                if (pVal.BeforeAction == false)
                                                {
                                                    oMatrix.FlushToDataSource();
                                                    oDBDSDetail.SetValue("U_CostC", pVal.Row - 1, oDataTable.GetValue("PrcCode", 0));
                                                    oDBDSDetail.SetValue("U_CostN", pVal.Row - 1, oDataTable.GetValue("PrcName", 0));
                                                    oMatrix.LoadFromDataSource();
                                                    oMatrix.Columns.Item("V_1").Cells.Item(pVal.Row).Click();
                                                }
                                                break;
                                            case "6676":
                                                if (pVal.BeforeAction == false)
                                                {
                                                    oMatrix.FlushToDataSource();
                                                    oDBDSDetail.SetValue("U_Reso", pVal.Row - 1, oDataTable.GetValue("ResName", 0));
                                                    oMatrix.LoadFromDataSource();
                                                   oMatrix.Columns.Item("V_2").Cells.Item(pVal.Row).Click();
                                                }
                                                break;
                                            case "V_1":
                                                if (pVal.BeforeAction == false)
                                                {
                                                    oMatrix.FlushToDataSource();
                                                    oDBDSDetail.SetValue("U_Emp", pVal.Row - 1, oDataTable.GetValue("PrcCode", 0));
                                                    oDBDSDetail.SetValue("U_EmpName", pVal.Row - 1, oDataTable.GetValue("PrcName", 0));
                                                    oMatrix.LoadFromDataSource();
                                                    oMatrix.Columns.Item("t_Proj").Cells.Item(pVal.Row).Click();
                                                }
                                                break;
                                            case "V_4":
                                                if (pVal.BeforeAction == false)
                                                {
                                                    oMatrix.FlushToDataSource();
                                                    oDBDSDetail.SetValue("U_Location", pVal.Row - 1, oDataTable.GetValue("PrcCode", 0));
                                                    oDBDSDetail.SetValue("U_LocationName", pVal.Row - 1, oDataTable.GetValue("PrcName", 0));
                                                    oMatrix.LoadFromDataSource();
                                                    oMatrix.Columns.Item("V_0").Cells.Item(pVal.Row).Click();
                                                }
                                                break;
                                            case "V_3":
                                                if (pVal.BeforeAction == false)
                                                {
                                                    oMatrix.FlushToDataSource();
                                                    oDBDSDetail.SetValue("U_Dept", pVal.Row - 1, oDataTable.GetValue("PrcCode", 0));
                                                    oDBDSDetail.SetValue("U_DeptName", pVal.Row - 1, oDataTable.GetValue("PrcName", 0));
                                                    oMatrix.LoadFromDataSource();
                                                    oMatrix.Columns.Item("6676").Cells.Item(pVal.Row).Click();
                                                }
                                                break;
                                            case "V_5":
                                                if (pVal.BeforeAction == false)
                                                {
                                                    oMatrix.FlushToDataSource();
                                                    oDBDSDetail.SetValue("U_BusUnit", pVal.Row - 1, oDataTable.GetValue("PrcCode", 0));
                                                    oDBDSDetail.SetValue("U_BusUnitName", pVal.Row - 1, oDataTable.GetValue("PrcName", 0));
                                                    oMatrix.LoadFromDataSource();
                                                    oMatrix.Columns.Item("V_4").Cells.Item(pVal.Row).Click();
                                                }
                                                break;
                                            case "t_Proj":
                                                if (pVal.BeforeAction == false)
                                                {
                                                    oMatrix.FlushToDataSource();
                                                    oDBDSDetail.SetValue("U_Prj", pVal.Row - 1, oDataTable.GetValue("PrjCode", 0));
                                                    oMatrix.LoadFromDataSource();
                                                    oMatrix.Columns.Item("V_5").Cells.Item(pVal.Row).Click();
                                                }
                                                break;
                                        }
                                        break;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            EventHandler.oApplication.StatusBar.SetText("Error: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                        }
                        finally
                        {
                        }
                        break;
                    #endregion

                    case SAPbouiCOM.BoEventTypes.et_DOUBLE_CLICK:

                        break;

                    /////////////////

                    //case SAPbouiCOM.BoEventTypes.et_PICKER_CLICKED:
                    //    try
                    //    {

                    //    }
                    //    catch (Exception ex)
                    //    {
                    //        EventHandler.oApplication.MessageBox(ex.Message + " Line No: " + ex.StackTrace);
                    //    }
                    //    finally
                    //    {
                    //    }

                    case SAPbouiCOM.BoEventTypes.et_KEY_DOWN:
                        try
                        {
                            if (pVal.BeforeAction == false) 
                            { 
                            if (pVal.ColUID == pVal.ColUID)
                            {
                                if (pVal.CharPressed == 38) // UP
                                {
                                    SAPbouiCOM.Form oForm = EventHandler.oApplication.Forms.ActiveForm;
                                    if ((pVal.Row != 1))
                                    {
                                        oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row - 1).Click(SAPbouiCOM.BoCellClickType.ct_Double);
                                    }
                                }
                            }
                        }
                            if (pVal.BeforeAction == false)
                            {
                                if (pVal.ColUID == pVal.ColUID)
                                {
                                    if (pVal.CharPressed == 40) // Down
                                    {
                                        SAPbouiCOM.Form oForm = EventHandler.oApplication.Forms.ActiveForm;
                                        if ((pVal.Row != oMatrix.RowCount))
                                        {
                                            oMatrix.Columns.Item(pVal.ColUID).Cells.Item(pVal.Row + 1).Click(SAPbouiCOM.BoCellClickType.ct_Double);
                                        }
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            EventHandler.oApplication.MessageBox(ex.Message);
                        }
                        finally
                        {
                        }

                        break;



                    ///////////////////
                    case SAPbouiCOM.BoEventTypes.et_GOT_FOCUS:
                        try
                        {
                            switch (pVal.ItemUID)
                            {
                                case "Matrix":
                                    switch (pVal.ColUID)
                                    {
                                        case "V_5":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFl_BU", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],2) = 'BU'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "V_11":
                                            if (pVal.BeforeAction == true)
                                            {
                                                GlobalVariables.oGFun.choosefromlistItem(frmIR, "CFL_itm", "ItemCode");
                                                //GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFL_itm", "ItemCode", String.Format("Select [ItemCode] from OITM where [validFor] = 'Y'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "V_4":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFl_Locat", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],1) = 'L'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "6676":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "Cfl_Resour", "ResCode", String.Format("SELECT *  FROM ORSC T0 WHERE T0.[frozenFor] ='N'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "V_3":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFl_Dapt", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],1) = 'D'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "V_2":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFL_cost", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],2) = 'CC'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "V_1":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFl_EmpCh", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],2) = 'E-'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "t_Proj":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFl_Proj", "PrjCode", String.Format("SELECT * FROM OPRJ T0 WHERE T0.[Active]  = 'Y' AND LEFT (T0.[PrjCode], 3) = 'CWP' ORDER BY T0.[PrjName] ASC").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;

                                    }
                                    break;
                            }
                        }
                        catch (Exception ex)
                        {
                            EventHandler.oApplication.MessageBox(ex.Message );
                        }
                        finally
                        {
                        }

                        break;
                    case SAPbouiCOM.BoEventTypes.et_COMBO_SELECT:
                        try
                        {
                            switch (pVal.ItemUID)
                            {

                                case "50000":

                                    if (pVal.BeforeAction == false)
                                    {
                                        SAPbouiCOM.ComboBox getType = (SAPbouiCOM.ComboBox)frmIR.Items.Item("50000").Specific;
                                        string docT = getType.Value.ToString();
                                        if (docT == "S")
                                        {
                                            serClose();
                                        }
                                        if (docT == "I")
                                        {
                                            itemClose();
                                        }
                                    }
                                    break;
                                case "Matrix":
                                    switch (pVal.ColUID)
                                    {
                                        case "t_LineSat":
                                            if (pVal.BeforeAction == false)
                                            {
                                                SAPbouiCOM.ComboBox oEdit = (SAPbouiCOM.ComboBox)oMatrix.Columns.Item("t_LineSat").Cells.Item(pVal.Row).Specific;
                                                string Value = oEdit.Value.ToString();

                                                SAPbouiCOM.ComboBox oService = (SAPbouiCOM.ComboBox)oMatrix.Columns.Item("t_LineSat").Cells.Item(pVal.Row).Specific;
                                                string service = oService.Value.ToString();
                                                SAPbouiCOM.EditText getType = (SAPbouiCOM.EditText)frmIR.Items.Item("t_User").Specific;
                                                string getUser = getType.Value.ToString() ?? "";
                                                string ActUser = GlobalVariables.oCompany.UserName;
                                                if (Value == "C" && getUser == ActUser)
                                                {
                                                    oMatrix.CommonSetting.SetRowEditable(pVal.Row, false);
                                                }
                                                else
                                                {
                                                    EventHandler.oApplication.StatusBar.SetText(("You canot Change Status Kindly connect with " + getUser), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                    //SAPbouiCOM.ComboBox oCombo = (SAPbouiCOM.ComboBox)oMatrix.Columns.Item("t_LineSat").Cells.Item(pVal.Row).Specific;

                                                    //oCombo.Select("", BoSearchKey.psk_ByDescription);
                                                    //if (EventHandler.oApplication.MessageBox("Kindly connect with " + getUser +"Do you want to continue?", 1, "Ok", "") == 1)
                                                    //{
                                                      frmIR.Mode =  SAPbouiCOM.BoFormMode.fm_OK_MODE;
                                                    //}

                                                    //oDBDSDetail.SetValue("U_Status", pVal.Row,"");
                                                    //if(lineStatus == "C")
                                                    //{
                                                    //((SAPbouiCOM.ComboBox)oMatrix.Columns.Item("t_LineSat").Cells.Item(oMatrix.RowCount).Specific).Selected.Value = "";
                                                    //oDBDSDetail.SetValue("U_Status", oMatrix.RowCount - 1, string.Empty);
                                                    ////SAPbouiCOM.ComboBox oLiscombo = ((SAPbouiCOM.ComboBox)oMatrix.Columns.Item("t_LineSat").Cells.Item(pVal.Row).Specific);
                                                    //  oLiscombo.Select("");
                                                    //oLineStat = null;
                                                    //  }
                                                    //(SAPbouiCOM.ComboBox)oMatrix.Columns.Item("t_LineSat").Cells.Item(pVal.Row).Specific;
                                                }
                                                if (Value == "C" && service == "I")
                                                {
                                                    oMatrix.CommonSetting.SetRowEditable(pVal.Row, false);
                                                }
                                            }
                                            break;
                                    }
                                    break;
                            }
                            break;
                        }
                        catch (Exception ex)
                        {
                            EventHandler.oApplication.MessageBox(ex.Message );
                            frmIR.Freeze(false);
                        }
                        break;
                    case SAPbouiCOM.BoEventTypes.et_LOST_FOCUS:
                        try
                        {
                            switch (pVal.ItemUID)
                            {
                                case "Matrix":
                                    switch (pVal.ColUID)
                                    {
                                        case "V_8":
                                            if(pVal.BeforeAction  == false)
                                            {
                                                double Quantity = Convert.ToDouble(oMatrix.Columns.Item("V_8").Cells.Item(pVal.Row).Specific.Value);
                                                frmIR.Freeze(true);
                                                if (Quantity <= 0)
                                                {
                                                    //EventHandler.oApplication.StatusBar.SetText(("You canot enter quantaty zero...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                                                    //oMatrix.Columns.Item("V_8").Cells.Item(pVal.Row).Click();
                                                }
                                                else
                                                {
                                                    oMatrix.FlushToDataSource();
                                                    //oMatrix.Columns.Item("V_100").Cells.Item(pVal.Row).Specific.Value = Quantity;
                                                    oDBDSDetail.SetValue("U_Sum", pVal.Row - 1, Convert.ToString(Quantity));
                                                    oMatrix.LoadFromDataSource();
                                                }
                                                frmIR.Freeze(false);
                                            }
                                            break;
                                        //case "6676":
                                        //  if (pVal.BeforeAction == false)
                                        //    {
                                        //        oMatrix.FlushToDataSource();
                                        //    }
                                        //    break;
                                        case "t_serDes":
                                            string ServDes = Convert.ToString(oMatrix.Columns.Item("t_serDes").Cells.Item(pVal.Row).Specific.Value);
                                            frmIR.Freeze(true);
                                            if (!string.IsNullOrEmpty(ServDes))
                                            {
                                                oDBDSDetail.SetValue("U_RDate", pVal.Row, GlobalVariables.oGFun.GetServerDate());
                                                oMatrix.FlushToDataSource();
                                                GlobalVariables.oGFun.SetNewLine(oMatrix, oDBDSDetail);
                                                oMatrix.LoadFromDataSource();
                                                //oComboBox = oMatrix.Columns.Item("t_DocType").Cells.Item(pVal.Row + 1).Specific;
                                                //oComboBox.Select("S");
                                                //oColumn = oColumns.Item("t_serDes");
                                                //oColumn.Editable = true;
                                                oMatrix.CommonSetting.SetRowEditable(pVal.Row + 1, true);
                                            }
                                            frmIR.Freeze(false);
                                            break;
                                    }
                                    break;
                            }
                        }
                        catch (Exception ex)
                        {
                            EventHandler.oApplication.MessageBox(ex.Message);
                        }
                        finally
                        {
                        }

                        break;
                    case SAPbouiCOM.BoEventTypes.et_CLICK:
                        try
                        {
                            switch (pVal.ItemUID)
                            {
                                case "t_Print":
                                    if (pVal.BeforeAction == false)
                                    {
                                        string ReportName = "Internal Requisition Report";
                                        GlobalVariables.oGFun.OpenReport(ReportName, oDBDSHeader.GetValue("DocNum", 0).Trim());
                                      //  if (EventHandler.oApplication.MessageBox("Do you want to print...?", 1, "Yes", "No", "") == 1)
                                      //  {
                                            //string path = "";
                                            //string myExeDir = new FileInfo(Assembly.GetEntryAssembly().Location).Directory.ToString();
                                            //myExeDir = myExeDir + @"\Configurtion.txt";
                                            //string rdText = File.ReadAllText(myExeDir);
                                            //Configuration ResPonse = JsonConvert.DeserializeObject<Configuration>(rdText);
                                            //ReportDocument cryRpt = new ReportDocument();
                                            //path = ResPonse.path;
                                            //path = @"C:\Report\";
                                            //cryRpt.Load(path + "Internal Requisition Report.rpt");

                                            //TableLogOnInfos crtableLogoninfos = new TableLogOnInfos();
                                            //TableLogOnInfo crtableLogoninfo = new TableLogOnInfo();
                                            //ConnectionInfo crConnectionInfo = new ConnectionInfo();
                                            //Tables CrTables;

                                            ////crConnectionInfo.ServerName = ResPonse.ServerName;
                                            ////crConnectionInfo.DatabaseName = ResPonse.DbName;
                                            ////crConnectionInfo.UserID = ResPonse.UserName;
                                            ////crConnectionInfo.Password = ResPonse.Password;

                                            //crConnectionInfo.ServerName = "NDB@sap.src.com.pk:30015";
                                            //crConnectionInfo.DatabaseName = "SRC_LIVE";
                                            //crConnectionInfo.UserID = "SYSTEM";
                                            //crConnectionInfo.Password = "@Core#@916";
                                            //cryRpt.SetDatabaseLogon(ResPonse.UserName, ResPonse.Password, ResPonse.ServerName, ResPonse.DbName);

                                            ////CrTables = cryRpt.Database.Tables;
                                            ////foreach (CrystalDecisions.CrystalReports.Engine.Table CrTable in CrTables)
                                            ////{
                                            ////    crtableLogoninfo = CrTable.LogOnInfo;
                                            ////    crtableLogoninfo.ConnectionInfo = crConnectionInfo;
                                            ////    CrTable.ApplyLogOnInfo(crtableLogoninfo);
                                            ////}

                                            //string Docm = oDBDSHeader.GetValue("DocNum", 0).Trim();
                                            ////cryRpt.SetParameterValue("DocNum", oDBDSHeader.GetValue("DocNum", 0).Trim());

                                            //cryRpt.RecordSelectionFormula = "";
                                            //cryRpt.RecordSelectionFormula += "{Command.DocNum} =" + oDBDSHeader.GetValue("DocNum", 0).Trim() + " AND ";
                                            //cryRpt.RecordSelectionFormula += " 1=1 ";

                                            //cryRpt.PrintToPrinter(2, true, 1, 2);
                                            //string datetime = "";
                                            //datetime = DateTime.Now.ToString("yyyy-MM-d m s");
                                            //cryRpt.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, path + datetime + " " + "DocNum " + oDBDSHeader.GetValue("DocNum", 0).Trim() + ".pdf");
                                        //}
                                    }
                                    break;
                                case "334":
                                    if (pVal.BeforeAction == true)
                                    {
                                        GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "cfl_BusinessUni", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],2) = 'BU'").Replace("[", "\"").Replace("]", "\""));
                                    }
                                    break;
                                case "335":
                                    if (pVal.BeforeAction == true)
                                    {
                                        GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "cfl_Location", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],1) = 'L'").Replace("[", "\"").Replace("]", "\""));
                                    }
                                    break;
                                case "Matrix":
                                    switch (pVal.ColUID)
                                    {
                                        case "V_5":
                                            if (pVal.BeforeAction == true)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFl_BU", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],2) = 'BU'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "V_11":
                                            if (pVal.BeforeAction == true)
                                            {
                                                GlobalVariables.oGFun.choosefromlistItem(frmIR, "CFL_itm", "ItemCode");
                                               //GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFL_itm", "ItemCode", String.Format("Select [ItemCode] from OITM where [validFor] = 'Y'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "V_4":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFl_Locat", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],1) = 'L'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "V_3":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFl_Dapt", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],1) = 'D'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "V_2":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFL_cost", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],2) = 'CC'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "V_1":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFl_EmpCh", "PrcCode", String.Format("SELECT * FROM OPRC WHERE LEFT([PrcCode],2) = 'E-'").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                        case "t_Proj":
                                            if (pVal.BeforeAction == false)
                                            {
                                                GlobalVariables.oGFun.ChooseFromListFilteration(frmIR, "CFl_Proj", "PrjCode", String.Format("SELECT * FROM OPRJ T0 WHERE T0.[Active]  = 'Y' AND LEFT (T0.[PrjCode], 3) = 'CWP' ORDER BY T0.[PrjName] ASC").Replace("[", "\"").Replace("]", "\""));
                                            }
                                            break;
                                    }
                                    break;
                            }
                        }
                        catch (Exception ex)
                        {
                            EventHandler.oApplication.MessageBox(ex.Message);
                        }
                        finally
                        {
                        }

                        break;
                    case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED:
                        try
                        {
                            switch (pVal.ItemUID)
                            {
                                case "1":
                                    if (pVal.ActionSuccess & frmIR.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE)
                                    {
                                        this.InitForm();
                                    }
                                    if (pVal.BeforeAction == true & (frmIR.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE | frmIR.Mode == SAPbouiCOM.BoFormMode.fm_UPDATE_MODE))
                                    {
                                        if (this.ValidateAll() == false)
                                        {
                                            System.Media.SystemSounds.Asterisk.Play();
                                            BubbleEvent = false;
                                            return;
                                        }
                                    }


                                    break;
                            }
                        }
                        catch (Exception ex)
                        {
                            EventHandler.oApplication.MessageBox(ex.Message + " Line No: " + ex.StackTrace);
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.MessageBox(ex.Message + " Line No: " + ex.StackTrace);
            }
            finally
            {
            }
        }


        public void RightClickEvent(ref SAPbouiCOM.ContextMenuInfo EventInfo, ref bool BubbleEvent)
        {
            try
            {
                switch (EventInfo.EventType)
                {
                    case SAPbouiCOM.BoEventTypes.et_RIGHT_CLICK:
                        {
                            frmIR.Freeze(true);
                            DeleteRowITEMUID = EventInfo.ItemUID;
                            switch (EventInfo.ItemUID)
                            {
                                case "Matrix":
                                    if (EventInfo.Row == oMatrix.VisualRowCount)
                                    {
                                        //frmIR.EnableMenu("1293", false);
                                    }
                                    else
                                    {
                                        frmIR.EnableMenu("1293", true);
                                    }
                                    oMatrix.FlushToDataSource();
                                    for (int i = 0; i <= oMatrix.RowCount - 1; i++)
                                    {
                                        oDBDSDetail.SetValue("LineID", i - 1, i.ToString());
                                        oMatrix.LoadFromDataSource();
                                    }
                                    break;

                                case "OOIRT":
                                    {
                                    }
                                    break;
                            }

                            break;
                        }

                }
                frmIR.Freeze(false);
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.MessageBox(ex.Message);
                frmIR.Freeze(false);

            }
            finally
            {
            }
        }


        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                switch (pVal.MenuUID)
                {
                    case "1281":
                        frmIR.Items.Item("t_DocNum").Enabled = true;
                        frmIR.Items.Item("t_Status").Enabled = true;
                        frmIR.Items.Item("t_EmpName").Enabled = true;
                        frmIR.Items.Item("t_Dept").Enabled = true;
                        frmIR.Items.Item("333").Enabled = true;
                        frmIR.Items.Item("t_User").Enabled = true;
                        frmIR.Items.Item("t_DocNum").Click();
                        break;
                    case "1282":
                        this.InitForm();
                        break;
                    case "1286":
                        if(pVal.BeforeAction == false)
                        {
                            string currtUser = GlobalVariables.oCompany.UserName;
                            if (!string.IsNullOrEmpty(closeDocNum) && closeDocType == "S" && closeUserName == currtUser)
                            {
                                SAPbobsCOM.Recordset oRecUpdate = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                                string query = string.Format("Update T0 set T0.[U_Status] = 'C' from [@AC_OIRT] T0 where  T0.[DocNum] = '" + closeDocNum + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecUpdate.DoQuery(query);
                                closeDocNum = "";
                                closeDocType = "";
                                closeUserName = "";
                            }
                            else
                            {
                                EventHandler.oApplication.StatusBar.SetText(("This User is not authorized for change the status..."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            }
                        }
                            //string Action = pVal.BeforeAction.ToString();
                            //string FormMode = frmIR.Mode.ToString();
                            //SAPbouiCOM.ComboBox doctype = (SAPbouiCOM.ComboBox)frmIR.Items.Item("50000").Specific;
                            //SAPbouiCOM.EditText gettype = (SAPbouiCOM.EditText)frmIR.Items.Item("t_User").Specific;
                            //SAPbouiCOM.EditText docno = (SAPbouiCOM.EditText)frmIR.Items.Item("t_DocNum").Specific;
                            //string getuser = gettype.Value.ToString() ?? "";
                            //string actuser = GlobalVariables.oCompany.UserName;
                            //string documenttyp = doctype.Value.ToString();
                            //string docnum = docno.Value.ToString();
                            //if (documenttyp == "s" && getuser == actuser)
                            //{
                            //    // odbdsheader.setvalue("u_status", 0, "c");
                            //}
                        break;
                    case "1293":
                        switch (DeleteRowITEMUID)
                        {
                            case "Matrix":
                                GlobalVariables.oGFun.DeleteRow(oMatrix, oDBDSDetail);
                                break;
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.MessageBox(ex.Message);
            }
            finally
            {

            }
        }
        #endregion

        #region FormEvents
        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, ref bool BubbleEvent)
        {
            try
            {
                // BubbleEvent = true;
                switch (BusinessObjectInfo.EventType)
                {
                    case SAPbouiCOM.BoEventTypes.et_FORM_DATA_ADD:
                        try
                        {
                            if (BusinessObjectInfo.BeforeAction)
                            {
                                if (ValidateAll() == false)
                                {
                                    BubbleEvent = false;
                                    return;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            EventHandler.oApplication.MessageBox(ex.Message );
                            BubbleEvent = false;
                        }
                        break;

                    //At Update Button
                    case SAPbouiCOM.BoEventTypes.et_FORM_DATA_UPDATE:
                        try
                        {
                            if (BusinessObjectInfo.BeforeAction)
                            {
                                if (ValidateAll() == true)
                                {
                                    int TotalItem = 0;
                                    int TotalClose = 0;
                                    SAPbouiCOM.EditText getType = (SAPbouiCOM.EditText)frmIR.Items.Item("t_DocNum").Specific;
                                    string DocNum = getType.Value.ToString();
                                    //For Matrix
                                    for (int i = 0; i < oMatrix.RowCount; i++)
                                    {
                                        string ItemCode = Convert.ToString(oMatrix.Columns.Item("V_11").Cells.Item(i + 1).Specific.Value);
                                        string Service = Convert.ToString(oMatrix.Columns.Item("t_serDes").Cells.Item(i + 1).Specific.Value);
                                        string LineStat = Convert.ToString(oMatrix.Columns.Item("t_LineSat").Cells.Item(i + 1).Specific.Value);
                                        if (!string.IsNullOrEmpty(ItemCode) || !string.IsNullOrEmpty(Service))
                                        {
                                            TotalItem++;
                                        }
                                        if(LineStat == "C")
                                        {
                                            TotalClose++;
                                        }
                                    }
                                    if (TotalItem == TotalClose)
                                    {
                                        SAPbobsCOM.Recordset oRecUpdate = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                                        //((SAPbouiCOM.ComboBox)frmIR.Items.Item("t_Status").Specific).Select("C", SAPbouiCOM.BoSearchKey.psk_ByValue);
                                        string UpdateMain = string.Format("Update T0 set T0.[U_Status] = 'C' from [@AC_OIRT] T0 where T0.[DocNum] = '" + DocNum + "'").Replace("[", "\"").Replace("]", "\"");
                                        oRecUpdate.DoQuery(UpdateMain);
                                        frmIR.Refresh();
                                        //EventHandler.oApplication.ActivateMenuItem("1304");
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            EventHandler.oApplication.MessageBox(ex.Message + " Line No: " + ex.StackTrace);
                            BubbleEvent = false;
                        }
                        break;

                    case SAPbouiCOM.BoEventTypes.et_FORM_CLOSE:
                        
                    case SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD:
                        try
                        {
                            if (BusinessObjectInfo.BeforeAction == false)
                            {
                                SAPbobsCOM.Recordset oRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                                closeDocNum  = Convert.ToString(oDBDSHeader.GetValue("DocNum", 0).ToString());
                                closeUserName  = Convert.ToString(oDBDSHeader.GetValue("U_User", 0).ToString());
                                closeDocType  = Convert.ToString(oDBDSHeader.GetValue("U_DocType", 0).ToString());
                                SAPbouiCOM.EditText DocNum = (SAPbouiCOM.EditText)frmIR.Items.Item("t_DocNum").Specific;
                                string Docno = DocNum.Value;
                                string query = string.Format("Select T1.[U_ItemCode],T0.[DocEntry],T1.[U_Status],T1.[LineId] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where (T1.[U_ItemCode] IS NOT NULL OR T1.[U_Descrpt] IS NOT NULL) and T0.[DocNum] = '" + Docno + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecord.DoQuery(query);

                                SAPbouiCOM.ComboBox getType = (SAPbouiCOM.ComboBox)frmIR.Items.Item("50000").Specific;
                                string docT = getType.Value.ToString();
                                for (int i = 0; i < oRecord.RecordCount; i++)
                                {

                                    SAPbouiCOM.EditText getUser = (SAPbouiCOM.EditText)frmIR.Items.Item("t_User").Specific;
                                    string getDocUser = getUser.Value.ToString() ?? "";
                                    string GetUname = GlobalVariables.oCompany.UserName;

                                    string Status = Convert.ToString(oRecord.Fields.Item("U_Status").Value);
                                    int LineID = Convert.ToInt32(oRecord.Fields.Item("LineId").Value);
                                    if (Status == "C" || getDocUser != GetUname)
                                    {
                                        oMatrix.CommonSetting.SetRowEditable(LineID, false);
                                        if(docT == "S")
                                        {
                                            oMatrix.Columns.Item("V_0").Editable = true;
                                        }
                                    }
                                    else
                                    {
                                        oMatrix.Item.Enabled = true;
                                        oMatrix.CommonSetting.SetRowEditable(LineID, true);
                                        oMatrix.Columns.Item("V_6").Editable = false;
                                        oMatrix.Columns.Item("V_100").Editable = false;
                                    }
                                    oRecord.MoveNext();
                                }
                                frmIR.Items.Item("t_DocNum").Enabled = false;
                                frmIR.Items.Item("t_Status").Enabled = false;
                                frmIR.Items.Item("t_EmpName").Enabled = false;
                                frmIR.Items.Item("t_Dept").Enabled = false;
                                frmIR.Items.Item("333").Enabled = false;
                                frmIR.Items.Item("t_User").Enabled = false;
                                if (docT == "S")
                                {
                                    serClose();
                                }
                                if (docT == "I")
                                {
                                    itemClose();
                                    string GetUname = GlobalVariables.oCompany.UserName;
                                    if (GetUname != "manager")
                                    {
                                        oMatrix.Item.Enabled = false;
                                    }
                                }


                                //For Manager Editable
                                string UserName = GlobalVariables.oCompany.UserName;
                                //if (UserName != "manager")
                                //{
                                //    oMatrix.Item.Enabled = false;
                                //}
                            }
                        }
                        catch (Exception ex)
                        {
                            EventHandler.oApplication.MessageBox(ex.Message );
                        }
                        break;
                }
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.MessageBox(ex.Message );
            }
            finally
            {
            }
        }
        #endregion



    }
}
