using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using SAPbouiCOM;
using System.Net.Mail;

using SAPbobsCOM;

namespace LMS
{
	//Imports System.IO.StreamReade
	/// <summary>
	/// Globally whatever Function and method do you want define here 
	/// We can use any class and module from here  
	/// </summary>
	/// <remarks></remarks>
	public class GlobalFunctions

	{
        string format = "yyyyMMdd";
        public static string contractNo = "";
        #region " ...  Common For Company ..."
        public void AddXML(string pathstr)
		{
			try {
				System.Xml.XmlDocument xmldoc = new System.Xml.XmlDocument();
                string[] abc = Assembly.GetExecutingAssembly().GetManifestResourceNames();

                System.IO.Stream stream = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("LMS." + pathstr);
				System.IO.StreamReader streamreader = new System.IO.StreamReader(stream, true);
				xmldoc.LoadXml(streamreader.ReadToEnd());
				streamreader.Close();
				EventHandler.oApplication.LoadBatchActions(xmldoc.InnerXml);
			} catch (Exception ex)   
            { 
				EventHandler.oApplication.StatusBar.SetText("AddXML Method Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
			} finally 
            {
			}
		}
		public bool FormExist(string FormID)
		{
			bool functionReturnValue = false;
			functionReturnValue = false;
			foreach (SAPbouiCOM.Form uid in EventHandler.oApplication.Forms) {
				if (uid.UniqueID == FormID) {
					functionReturnValue = true;
					return functionReturnValue;
				}
			}
			if (functionReturnValue) {
				EventHandler.oApplication.Forms.Item(FormID).Visible = true;
				EventHandler.oApplication.Forms.Item(FormID).Select();
			}
			return functionReturnValue;
		}
		public int ConnectionContext()
		{
			int functionReturnValue = 0;
			try {
				int strErrorCode ;
				if (GlobalVariables.oCompany.Connected == true)
					GlobalVariables.oCompany.Disconnect();

				EventHandler.oApplication.StatusBar.SetText("Connecting " + GlobalVariables.addonName + " Addon With The Company..........      Please Wait ..........", SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
				strErrorCode = GlobalVariables.oCompany.Connect();
				functionReturnValue = strErrorCode;

				dynamic a = GlobalVariables.oCompany.GetLastErrorDescription();
				dynamic b = GlobalVariables.oCompany.GetLastErrorCode();


				if (strErrorCode == 0) {
					EventHandler.oApplication.StatusBar.SetText("ADDON for  " + GlobalVariables.addonName + " Module - Connection Established  !!! ", SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
					System.Media.SystemSounds.Asterisk.Play();
				} else {
					EventHandler.oApplication.StatusBar.SetText("Failed To Connect, Please Check The License Configuration....." + GlobalVariables.oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Long, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
				}
			} catch (Exception ex) {
				EventHandler.oApplication.StatusBar.SetText(ex.Message);
			} finally {
			}
			return functionReturnValue;
		}
		public int CookieConnect()
		{
			int functionReturnValue = 0;
			try {
				string strCkie = null;
				string strContext = null;
				GlobalVariables.oCompany = new SAPbobsCOM.Company();
				Debug.Print(GlobalVariables.oCompany.CompanyDB);
				strCkie = GlobalVariables.oCompany.GetContextCookie();
				strContext = EventHandler.oApplication.Company.GetConnectionContext(strCkie);
				functionReturnValue = GlobalVariables.oCompany.SetSboLoginContext(strContext);
			} catch (Exception ex) {
				EventHandler.oApplication.StatusBar.SetText(ex.Message);
			} finally {
			}
			return functionReturnValue;
		}
		public void SetApplication()
		{
			try {
                SAPbouiCOM.SboGuiApi oGUI = null;
                oGUI= new SAPbouiCOM.SboGuiApi();
				oGUI.AddonIdentifier = "";
                //Connection String Coming from project debug properties
                string ConnectionString = Environment.GetCommandLineArgs().GetValue(1).ToString();
                oGUI.Connect(ConnectionString);
				EventHandler.oApplication = oGUI.GetApplication();
			} catch (Exception ex) {
				EventHandler.oApplication.StatusBar.SetText(ex.Message);
			} finally {
			}
		}
		#endregion

		#region " ... Menu Creation ..."

		public void LoadXML(SAPbouiCOM.Form Form, string FormId, string FormXML)
		{
			try {
				AddXML(FormXML);
				Form = EventHandler.oApplication.Forms.Item(FormId);
				Form.Select();
			} catch (Exception ex) {
				EventHandler.oApplication.StatusBar.SetText("LoadXML Method Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
			} finally {
			}
		}

        #endregion

        #region " ... Common For Data Base Creation ...   "
        public bool UDOExists(string code)
        {
            GC.Collect();
            SAPbobsCOM.UserObjectsMD v_UDOMD = null;
            bool v_ReturnCode = false;
            v_UDOMD = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD);
            v_ReturnCode = v_UDOMD.GetByKey(code);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UDOMD);
            v_UDOMD = null;
            return v_ReturnCode;
        }

        public bool CreateTable(string TableName, string TableDesc, SAPbobsCOM.BoUTBTableType TableType)
        {
            bool functionReturnValue = false;
            functionReturnValue = false;
            long v_RetVal = 0;
            int v_ErrCode = 0;
            string v_ErrMsg = "";
            try
            {
                if (!this.TableExists(TableName))
                {
                    SAPbobsCOM.UserTablesMD v_UserTableMD = null;
                    EventHandler.oApplication.StatusBar.SetText("Creating Table " + TableName + " ...................", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                    v_UserTableMD = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserTables);
                    v_UserTableMD.TableName = TableName;
                    v_UserTableMD.TableDescription = TableDesc;
                    v_UserTableMD.TableType = TableType;
                    v_RetVal = v_UserTableMD.Add();
                    if (v_RetVal != 0)
                    {
                        GlobalVariables.oCompany.GetLastError(out v_ErrCode, out v_ErrMsg);
                        EventHandler.oApplication.StatusBar.SetText("Failed to Create Table " + TableDesc + v_ErrCode + " " + v_ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UserTableMD);
                        v_UserTableMD = null;
                        return false;
                    }
                    else
                    {
                        EventHandler.oApplication.StatusBar.SetText("[" + TableName + "] - " + TableDesc + " Created Successfully!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UserTableMD);
                        v_UserTableMD = null;
                        return true;
                    }
                }
                else
                {
                    GC.Collect();
                    return false;
                }
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText(GlobalVariables.addonName + ":> " + ex.Message + " @ " + ex.Source);
            }
            return functionReturnValue;
        }

        public bool ColumnExists(string TableName, string FieldID)
        {
            try
            {
                SAPbobsCOM.Recordset rs = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                bool oFlag = true;
                string tedt = "Select 1 from CUFD Where \"TableID\"='" + Strings.Trim(TableName) + "' and \"AliasID\"='" + Strings.Trim(FieldID) + "'";
                rs.DoQuery("Select 1 from CUFD Where \"TableID\"='" + Strings.Trim(TableName) + "' and \"AliasID\"='" + Strings.Trim(FieldID) + "'");
                if (rs.EoF)
                    oFlag = false;
                System.Runtime.InteropServices.Marshal.ReleaseComObject(rs);
                rs = null;
                GC.Collect();
                return oFlag;
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText(ex.Message);
                return false;
            }
        }

        public bool UDFExists(string TableName, string FieldID)
        {
            try
            {
                SAPbobsCOM.Recordset rs = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                bool oFlag = true;
                rs.DoQuery("Select 1 from CUFD Where \"TableID\"='" + Strings.Trim(TableName) + "' and \"AliasID\"='" + Strings.Trim(FieldID) + "'");
                if (rs.EoF)
                    oFlag = false;
                System.Runtime.InteropServices.Marshal.ReleaseComObject(rs);
                rs = null;
                GC.Collect();
                return oFlag;
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText(ex.Message);
                return false;
            }
        }

        internal void ChooseFromListFilteration(SAPbouiCOM.Form frmDisAssgn, string v1, string v2, Recordset orecord)
        {
            throw new NotImplementedException();
        }

        public bool TableExists(string TableName)
        {
            SAPbobsCOM.UserTablesMD oTables = null;
            bool oFlag = false;
            oTables = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserTables);
            oFlag = oTables.GetByKey(TableName);
            System.Runtime.InteropServices.Marshal.ReleaseComObject(oTables);
            return oFlag;
        }
        public bool CreateUserFields(string TableName, string FieldName, string FieldDescription, SAPbobsCOM.BoFieldTypes type, int size = 0, SAPbobsCOM.BoFldSubTypes subType = SAPbobsCOM.BoFldSubTypes.st_None, string LinkedTable = "", string DefaultValue = "")
        {
            try
            {
                if (TableName.StartsWith("@") == true)
                {
                    if (!this.ColumnExists(TableName, FieldName))
                    {
                        SAPbobsCOM.UserFieldsMD v_UserField = null;
                        v_UserField = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields);
                        v_UserField.TableName = TableName;
                        v_UserField.Name = FieldName;
                        v_UserField.Description = FieldDescription;
                        v_UserField.Type = type;
                        if (type != SAPbobsCOM.BoFieldTypes.db_Date)
                        {
                            if (type != SAPbobsCOM.BoFieldTypes.db_Numeric)
                            {
                                if (size != 0)
                                {
                                    v_UserField.Size = size;
                                }
                            }
                            else
                            {
                                v_UserField.EditSize = size;
                            }
                          }
                        if (subType != SAPbobsCOM.BoFldSubTypes.st_None)
                        {
                            v_UserField.SubType = subType;
                        }
                        if (!string.IsNullOrEmpty(LinkedTable))
                            v_UserField.LinkedTable = LinkedTable;
                        if (!string.IsNullOrEmpty(DefaultValue))
                            v_UserField.DefaultValue = DefaultValue;

                        GlobalVariables.v_RetVal = v_UserField.Add();
                        if (GlobalVariables.v_RetVal != 0)
                        {
                            GlobalVariables.oCompany.GetLastError(out GlobalVariables.v_ErrCode, out GlobalVariables.v_ErrMsg);
                            EventHandler.oApplication.StatusBar.SetText("Failed to add UserField masterid" + GlobalVariables.v_ErrCode + " " + GlobalVariables.v_ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UserField);
                            v_UserField = null;
                            return false;
                        }
                        else
                        {
                            EventHandler.oApplication.StatusBar.SetText("[" + TableName + "] - " + FieldDescription + " added successfully!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UserField);
                            v_UserField = null;
                            return true;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }

                if (TableName.StartsWith("@") == false)
                {
                    if (!this.UDFExists(TableName, FieldName))
                    {
                        SAPbobsCOM.UserFieldsMD v_UserField = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserFields);
                        v_UserField.TableName = TableName;
                        v_UserField.Name = FieldName;
                        v_UserField.Description = FieldDescription;
                        v_UserField.Type = type;
                        if (type != SAPbobsCOM.BoFieldTypes.db_Date)
                        {
                            if (size != 0)
                            {
                                v_UserField.Size = size;
                            }
                        }
                        if (subType != SAPbobsCOM.BoFldSubTypes.st_None)
                        {
                            v_UserField.SubType = subType;
                        }
                        if (!string.IsNullOrEmpty(LinkedTable))
                            v_UserField.LinkedTable = LinkedTable;
                        GlobalVariables.v_RetVal = v_UserField.Add();
                        if (GlobalVariables.v_RetVal != 0)
                        {
                            GlobalVariables.oCompany.GetLastError(out GlobalVariables.v_ErrCode, out GlobalVariables.v_ErrMsg);
                            EventHandler.oApplication.StatusBar.SetText("Failed to add UserField " + FieldDescription + " - " + GlobalVariables.v_ErrCode + " " + GlobalVariables.v_ErrMsg, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UserField);
                            v_UserField = null;
                            return false;
                        }
                        else
                        {
                            EventHandler.oApplication.StatusBar.SetText(" & TableName & - " + FieldDescription + " added successfully!!!", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(v_UserField);
                            v_UserField = null;
                            return true;
                        }

                    }
                    else
                    {
                        return false;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.MessageBox(ex.Message);
                return false;
            }
        }
        public bool RegisterUDO(string UDOCode, string UDOName, SAPbobsCOM.BoUDOObjType UDOType, string[,] FindField, string UDOHTableName, string UDODTableName = "", string ChildTable = "", string ChildTable1 = "", string ChildTable2 = "", string ChildTable3 = "",
        string ChildTable4 = "", string ChildTable5 = "", string ChildTable6 = "", string ChildTable7 = "", string ChildTable8 = "", string ChildTable9 = "", SAPbobsCOM.BoYesNoEnum LogOption = SAPbobsCOM.BoYesNoEnum.tNO)
        {
            bool functionReturnValue = false;
            bool ActionSuccess = false;
            try
            {
                functionReturnValue = false;
                SAPbobsCOM.UserObjectsMD v_udoMD = null;
                v_udoMD = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.oUserObjectsMD);
                v_udoMD.CanCancel = SAPbobsCOM.BoYesNoEnum.tYES;
                v_udoMD.CanClose = SAPbobsCOM.BoYesNoEnum.tYES;
                v_udoMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tNO;
                v_udoMD.CanDelete = SAPbobsCOM.BoYesNoEnum.tYES;
                v_udoMD.CanFind = SAPbobsCOM.BoYesNoEnum.tYES;
                v_udoMD.CanLog = SAPbobsCOM.BoYesNoEnum.tYES;
                v_udoMD.CanYearTransfer = SAPbobsCOM.BoYesNoEnum.tYES;
                v_udoMD.ManageSeries = SAPbobsCOM.BoYesNoEnum.tYES;
                v_udoMD.Code = UDOCode;
                v_udoMD.Name = UDOName;
                v_udoMD.TableName = UDOHTableName;
                v_udoMD.CanCreateDefaultForm = SAPbobsCOM.BoYesNoEnum.tYES;
                if (!string.IsNullOrEmpty(UDODTableName))
                {
                    v_udoMD.ChildTables.TableName = UDODTableName;
                    v_udoMD.ChildTables.Add();
                }

                if (!string.IsNullOrEmpty(ChildTable))
                {
                    v_udoMD.ChildTables.TableName = ChildTable;
                    v_udoMD.ChildTables.Add();
                }
                if (!string.IsNullOrEmpty(ChildTable1))
                {
                    v_udoMD.ChildTables.TableName = ChildTable1;
                    v_udoMD.ChildTables.Add();
                }
                if (!string.IsNullOrEmpty(ChildTable2))
                {
                    v_udoMD.ChildTables.TableName = ChildTable2;
                    v_udoMD.ChildTables.Add();
                }
                if (!string.IsNullOrEmpty(ChildTable3))
                {
                    v_udoMD.ChildTables.TableName = ChildTable3;
                    v_udoMD.ChildTables.Add();
                }
                if (!string.IsNullOrEmpty(ChildTable4))
                {
                    v_udoMD.ChildTables.TableName = ChildTable4;
                    v_udoMD.ChildTables.Add();
                }
                if (!string.IsNullOrEmpty(ChildTable5))
                {
                    v_udoMD.ChildTables.TableName = ChildTable5;
                    v_udoMD.ChildTables.Add();
                }
                if (!string.IsNullOrEmpty(ChildTable6))
                {
                    v_udoMD.ChildTables.TableName = ChildTable6;
                    v_udoMD.ChildTables.Add();
                }
                if (!string.IsNullOrEmpty(ChildTable7))
                {
                    v_udoMD.ChildTables.TableName = ChildTable7;
                    v_udoMD.ChildTables.Add();
                }
                if (!string.IsNullOrEmpty(ChildTable8))
                {
                    v_udoMD.ChildTables.TableName = ChildTable8;
                    v_udoMD.ChildTables.Add();
                }
                if (!string.IsNullOrEmpty(ChildTable9))
                {
                    v_udoMD.ChildTables.TableName = ChildTable9;
                    v_udoMD.ChildTables.Add();
                }

                if (LogOption == SAPbobsCOM.BoYesNoEnum.tYES)
                {
                    v_udoMD.CanLog = SAPbobsCOM.BoYesNoEnum.tYES;
                    v_udoMD.LogTableName = "A" + UDOHTableName;
                }
                v_udoMD.ObjectType = UDOType;
                for (Int16 i = 0; i <= FindField.GetLength(0) - 1; i++)
                {
                    if (i > 0)
                        v_udoMD.FindColumns.Add();
                    v_udoMD.FindColumns.ColumnAlias = FindField[i, 0];
                    v_udoMD.FindColumns.ColumnDescription = FindField[i, 1];
                }

                if (v_udoMD.Add() == 0)
                {
                    functionReturnValue = true;
                    if (GlobalVariables.oCompany.InTransaction)
                        GlobalVariables.oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_Commit);
                    EventHandler.oApplication.StatusBar.SetText("Successfully Registered UDO >" + UDOCode + ">" + UDOName + " >" + GlobalVariables.oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                }
                else
                {
                    EventHandler.oApplication.StatusBar.SetText("Failed to Register UDO >" + UDOCode + ">" + UDOName + " >" + GlobalVariables.oCompany.GetLastErrorDescription(), SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    MessageBox.Show(GlobalVariables.oCompany.GetLastErrorDescription());
                    functionReturnValue = false;
                }
                System.Runtime.InteropServices.Marshal.ReleaseComObject(v_udoMD);
                v_udoMD = null;
                GC.Collect();
                if (ActionSuccess == false & GlobalVariables.oCompany.InTransaction)
                    GlobalVariables.oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack);
            }
            catch (Exception)
            {
                if (GlobalVariables.oCompany.InTransaction)
                    GlobalVariables.oCompany.EndTransaction(SAPbobsCOM.BoWfTransOpt.wf_RollBack);
            }
            return functionReturnValue;
        }
        #endregion

        #region "       Functions  & Methods            "



        public void DeleteRow(SAPbouiCOM.Matrix oMatrix, SAPbouiCOM.DBDataSource oDBDSDetail)
        {
            try
            {
                oMatrix.FlushToDataSource();

                for (int i = 1; i <= oMatrix.VisualRowCount; i++)
                {
                    oMatrix.GetLineData(i);
                    oDBDSDetail.Offset = i - 1;

                    oDBDSDetail.SetValue("LineID", oDBDSDetail.Offset, i.ToString());

                    oMatrix.SetLineData(i);
                    oMatrix.FlushToDataSource();

                }
                oDBDSDetail.RemoveRecord(oDBDSDetail.Size - 1);
                oMatrix.LoadFromDataSource();


            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("DeleteRow  Method Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
            finally
            {
            }
        }


        public bool GenerateContract(String bankCode, string customerCode, string customerName, double exchangeRate, double amount, DateTime dealDate,string docNum, string objectType)
        {
            bool functionReturnValue = false;
            try
            {
                SAPbobsCOM.GeneralService oGeneralService = null;
                SAPbobsCOM.GeneralData oGeneralData = null;
                SAPbobsCOM.GeneralDataParams oGeneralParams = null;
                SAPbobsCOM.CompanyService sCmp = null;
                SAPbobsCOM.GeneralData oChild = null;
                SAPbobsCOM.GeneralDataCollection oChildren = null;
                sCmp = GlobalVariables.oCompany.GetCompanyService();
                try
                {
                    oGeneralService = sCmp.GetGeneralService("OODCT");
                    // Get UDO record   
                    string query = string.Format("SELECT Top 1 a.[LineId],a.[DocEntry],a.[U_Cntct] FROM [@DCT1] a  Order by a.[LineId] Desc").Replace("[", "\"").Replace("]", "\"");
                    SAPbobsCOM.Recordset queryRec = GlobalVariables.oGFun.DoQuery(query);
                    string queryTwo = string.Format("SELECT Top 1 [U_RefNo],[DocEntry] FROM [@DCT1] WHERE Month(Current_date)=('" + DateTime.Now.Month + "')  Order by [LineId] Desc").Replace("[", "\"").Replace("]", "\"");
                    SAPbobsCOM.Recordset queryTwoRec = GlobalVariables.oGFun.DoQuery(queryTwo);
                    string bankRate = string.Format("SELECT [U_BnkRat] FROM [@BNR1] WHERE [U_Bank]='" + bankCode + "' ").Replace("[", "\"").Replace("]", "\"");
                    SAPbobsCOM.Recordset bankRateRec = GlobalVariables.oGFun.DoQuery(bankRate);
                    string customerPrice = string.Format("SELECT [U_Pric] FROM [@DCS1] a WHERE [U_PrtId] = '" + customerCode + "'").Replace("[", "\"").Replace("]", "\"");
                    SAPbobsCOM.Recordset customerPriceRec = GlobalVariables.oGFun.DoQuery(customerPrice);
                    oGeneralParams = ((SAPbobsCOM.GeneralDataParams)(oGeneralService.GetDataInterface(SAPbobsCOM.GeneralServiceDataInterfaces.gsGeneralDataParams)));
                    oGeneralParams.SetProperty("DocEntry", queryRec.Fields.Item("DocEntry").Value);
                    oGeneralData = oGeneralService.GetByParams(oGeneralParams);
                    // Add lines on UDO Child Table              
                    oChildren = oGeneralData.Child("DCT1");
                    // Update an existing line
                    oChild = oChildren.Add();
                    oChild.SetProperty("U_PrtyId", customerCode);
                    oChild.SetProperty("U_PrtyNm", customerName);
                    oChild.SetProperty("U_ExcRat", exchangeRate);
                    Double contract = Convert.ToDouble(queryRec.Fields.Item("U_Cntct").Value) + 1;
                    oChild.SetProperty("U_Cntct", Convert.ToString((contract)));
                    GlobalVariables.contractNo = Convert.ToString(contract);
                    //double contractAmount = (((amount + (amount * Convert.ToDouble(bankRateRec.Fields.Item("U_BnkRat").Value))) / exchangeRate) / 1000) * 1000;
                    double contractAmount = (amount + (amount * .1));
                    oChild.SetProperty("U_TotCnM", Convert.ToString(contractAmount / Convert.ToDouble(customerPriceRec.Fields.Item("U_Pric").Value)));
                    oChild.SetProperty("U_TotCnAm", contractAmount.ToString());
                   // oChild.SetProperty("U_Packng", "500 Meters = 1 ");
                    oChild.SetProperty("U_Packng", "500 Meters = 1 Roll (Export Packing)");
                    oChild.SetProperty("U_RefNo", Convert.ToString((Convert.ToDouble(queryTwoRec.Fields.Item("U_RefNo").Value) + 1)));
                    oChild.SetProperty("U_ConDat", DateTime.ParseExact(dealDate.AddMonths(-1).ToString("yyyyMMdd"), format, System.Globalization.CultureInfo.InvariantCulture));
                    DateTime negDate = dealDate.AddMonths(2);
                    DateTime newNegDate;
                    if (Convert.ToInt16(negDate.Day) <= 15)
                    {
                        newNegDate = negDate.AddDays(-Convert.ToDouble(negDate.Day)).AddDays(15);
                        oChild.SetProperty("U_NegDat", DateTime.ParseExact(GetNextWorkingDate(newNegDate), format, System.Globalization.CultureInfo.InvariantCulture));
                        oChild.SetProperty("U_ShDt", DateTime.ParseExact(GetNextWorkingDate(newNegDate.AddDays(-14)), format, System.Globalization.CultureInfo.InvariantCulture));
                    }
                    else if (Convert.ToInt16(negDate.Day) > 15)
                    {
                        newNegDate = negDate.AddDays(-Convert.ToDouble(negDate.Day)).AddDays(30);
                        oChild.SetProperty("U_NegDat", DateTime.ParseExact(GetNextWorkingDate(newNegDate), format, System.Globalization.CultureInfo.InvariantCulture));
                        oChild.SetProperty("U_ShDt", DateTime.ParseExact(GetNextWorkingDate(newNegDate.AddDays(-14)), format, System.Globalization.CultureInfo.InvariantCulture));
                    }
                    oChild.SetProperty("U_CovDat", DateTime.ParseExact(DateTime.Now.ToString("yyyyMMdd"), format, System.Globalization.CultureInfo.InvariantCulture));
                    oChild.SetProperty("U_LoanTp", objectType);
                    oChild.SetProperty("U_DocNm", docNum);
                    //Update the UDO Record
                    oGeneralService.Update(oGeneralData);
                    EventHandler.oApplication.StatusBar.SetText("Dummy Contract Generated with Contract No. '" + Convert.ToString((Convert.ToDouble(queryRec.Fields.Item("U_Cntct").Value) + 1))
                        + "' ", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    functionReturnValue = true;
                }
                catch (Exception ex)
                {
                    EventHandler.oApplication.MessageBox(ex.Message, 1, "OK", null, null);
                }

            }
            catch (Exception ex)
            {
                EventHandler.oApplication.MessageBox(ex.Message);
                functionReturnValue = false;
            }
            finally
            {
            }
            return functionReturnValue;
        }

        public bool OpenReport(String ReportName,string DocNum)
        {
            bool functionReturnValue = false;
            try
            {
                String ReportData = string.Format("SELECT [MenuUID] FROM OCMN where [Name] = '" + ReportName + "'").Replace("[", "\"").Replace("]", "\"");
                SAPbobsCOM.Recordset ReportRec = GlobalVariables.oGFun.DoQuery(ReportData);
                if (ReportRec.RecordCount == 0)
                {
                    EventHandler.oApplication.StatusBar.SetText("Report is not available in system: ", SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    return false;
                }
                else if (ReportRec.RecordCount != 0)
                {
                    String menuid = ReportRec.Fields.Item("MenuUID").Value;
                    EventHandler.oApplication.ActivateMenuItem(menuid);
                    SAPbouiCOM.Form oForm = EventHandler.oApplication.Forms.ActiveForm;
                    if (DocNum != "") { 
                    oForm.Items.Item("1000003").Specific.Value = DocNum;
                    oForm.Items.Item("1").Click();
                    oForm.Visible = false;
                    }
                    functionReturnValue = true;
                }
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.MessageBox(ex.Message);
                functionReturnValue = false;
            }
            finally
            {
            }
            return functionReturnValue;
        }
        public string GetServerDate()
		{
			try {
				SAPbobsCOM.SBObob rsetBob = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoBridge);
				SAPbobsCOM.Recordset rsetServerDate = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

				rsetServerDate = rsetBob.Format_StringToDate(EventHandler.oApplication.Company.ServerDate);

				return Convert.ToDateTime(rsetServerDate.Fields.Item(0).Value).ToString("yyyyMMdd");

			} catch (Exception ex) {
				GlobalVariables.oGFun.StatusBarErrorMsg("Get Server Date Function Failed : " + ex.Message);
				return "";
			} finally {
			}
		}
        public string GetNextWorkingDate(DateTime date)
        {
            try
            {
                DateTime workingDate = date;
                string sDay = date.DayOfWeek.ToString();
                if (sDay == "Sunday")
                {
                    //EventHandler.oApplication.MessageBox("Because of Sunday Date Shifted to Next Working Day ...!");
                    workingDate = date.AddDays(1);
                }
                else if (sDay == "Saturday") {
                    //EventHandler.oApplication.MessageBox("Because of Saturday Date Shifted to Next Working Day ...!");
                    workingDate = date.AddDays(2);
                }
                return Convert.ToDateTime(workingDate).ToString("yyyyMMdd");
            }
            catch (Exception ex)
            {
                GlobalVariables.oGFun.StatusBarErrorMsg("Next Working date : " + ex.Message);
                return "";
            }
            finally
            {
            }
        }
        public string GetPreviousWorkingDate(DateTime date)
        {
            try
            {
                DateTime workingDate = date;
                string sDay = date.DayOfWeek.ToString();
                if (sDay == "Sunday")
                {
                    //EventHandler.oApplication.MessageBox("Because of Sunday Date Shifted to Next Working Day ...!");
                    workingDate = date.AddDays(1);
                }
                else if (sDay == "Saturday")
                {
                    //EventHandler.oApplication.MessageBox("Because of Saturday Date Shifted to Next Working Day ...!");
                    workingDate = date.AddDays(2);
                }
                return Convert.ToDateTime(workingDate).ToString("yyyyMMdd");
            }
            catch (Exception ex)
            {
                GlobalVariables.oGFun.StatusBarErrorMsg("Next Working date : " + ex.Message);
                return "";
            }
            finally
            {
            }
        }
        public string GetDay(DateTime date)
        {
            try
            {
                string sDay = date.DayOfWeek.ToString();
               return sDay;
            }
            catch (Exception ex)
            {
                GlobalVariables.oGFun.StatusBarErrorMsg("Next Working date : " + ex.Message);
                return "";
            }
            finally
            {
            }
        }
        public SAPbobsCOM.Recordset DoQuery(string strSql)
		{
			try {
				SAPbobsCOM.Recordset rsetCode = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
				rsetCode.DoQuery(strSql);
				return rsetCode;
			} catch (Exception ex) {
				EventHandler.oApplication.StatusBar.SetText("Execute Query Function Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
				return null;
			} finally {
			}
		}
        public void LoadComboBox(SAPbouiCOM.ComboBox oComboBox, string strQry)
        {
            try
            {
                while (oComboBox.ValidValues.Count > 0)
                {
                    oComboBox.ValidValues.Remove(0, SAPbouiCOM.BoSearchKey.psk_Index);
                }
                if (oComboBox.ValidValues.Count == 0)
                {
                    SAPbobsCOM.Recordset rsetValidValue = (SAPbobsCOM.Recordset)GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    //Dim strQry As String = "SELECT Code , Location FROM OLCT"

                    rsetValidValue.DoQuery(strQry);
                    rsetValidValue.MoveFirst();
                    for (int j = 0; j <= rsetValidValue.RecordCount - 1; j++)
                    {
                        oComboBox.ValidValues.Add(Convert.ToString(rsetValidValue.Fields.Item(0).Value), Convert.ToString(rsetValidValue.Fields.Item(1).Value));
                        rsetValidValue.MoveNext();
                    }
                    oComboBox.ValidValues.Add("New", "Define New");
                }

            }
            catch (Exception ex)
            {
                GlobalVariables.oGFun.StatusBarErrorMsg("SetComboBoxValueRefresh Method Faild : " + ex.Message);
            }
            finally
            {
            }
        }
        public bool removeValidValues(SAPbouiCOM.ComboBox _combo)
        {
            try
            {
                while (_combo.ValidValues.Count > 0)
                {
                    _combo.ValidValues.Remove(0, SAPbouiCOM.BoSearchKey.psk_Index);
                }
                return true;
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                return false;
            }
        }
        public bool setComboBoxInvoiceStype(SAPbouiCOM.ComboBox oComboBox, string strQry)
        {
            try
            {
                SAPbobsCOM.Recordset rsetValidValue = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

                if (oComboBox.ValidValues.Count == 0)
                {
                    rsetValidValue.DoQuery(strQry);
                    rsetValidValue.MoveFirst();
                    for (int j = 0; j <= rsetValidValue.RecordCount - 1; j++)
                    {
                        oComboBox.ValidValues.Add(rsetValidValue.Fields.Item(0).Value, rsetValidValue.Fields.Item(1).Value);
                        rsetValidValue.MoveNext();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("setComboBoxValue Function Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return true;
            }
            finally
            {
            }

        }
        public bool setComboBoxCurrency(SAPbouiCOM.ComboBox oComboBox, string strQry)
        {
            try
            {
                SAPbobsCOM.Recordset rsetValidValue = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

                if (oComboBox.ValidValues.Count == 0)
                {
                    rsetValidValue.DoQuery(strQry);
                    rsetValidValue.MoveFirst();
                    for (int j = 0; j <= rsetValidValue.RecordCount - 1; j++)
                    {
                        oComboBox.ValidValues.Add(rsetValidValue.Fields.Item(0).Value, rsetValidValue.Fields.Item(1).Value);
                        rsetValidValue.MoveNext();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("setComboBoxValue Function Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return true;
            }
            finally
            {
            }

        }
        public bool setComboBoxBranches(SAPbouiCOM.ComboBox oComboBox, string strQry)
		{
			try {
				SAPbobsCOM.Recordset rsetValidValue = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

				if (oComboBox.ValidValues.Count == 0) {
					rsetValidValue.DoQuery(strQry);
					rsetValidValue.MoveFirst();
					for (int j = 0; j <= rsetValidValue.RecordCount - 1; j++) {
						oComboBox.ValidValues.Add(rsetValidValue.Fields.Item(0).Value, rsetValidValue.Fields.Item(1).Value);
						rsetValidValue.MoveNext();
					}
				}
                return true;
			} catch (Exception ex) {
				EventHandler.oApplication.StatusBar.SetText("setComboBoxValue Function Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
				return true;
			} finally {
			}

		}
        public bool setComboBoxSeriesBranches(SAPbouiCOM.ComboBox oComboBox, string strQry)
        {
            try
            {
                SAPbobsCOM.Recordset rsetValidValue = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                removeValidValues(oComboBox);
                if (oComboBox.ValidValues.Count == 0)
                {
                    rsetValidValue.DoQuery(strQry);
                    rsetValidValue.MoveFirst();
                    for (int j = 0; j <= rsetValidValue.RecordCount - 1; j++)
                    {
                        oComboBox.ValidValues.Add(rsetValidValue.Fields.Item(0).Value, rsetValidValue.Fields.Item(1).Value);
                        rsetValidValue.MoveNext();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("setComboBoxValue Function Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return true;
            }
            finally
            {
            }

        }
        public bool setComboBoxInvoice(SAPbouiCOM.ComboBox oComboBox, string strQry)
        {
            try
            {
                SAPbobsCOM.Recordset rsetValidValue = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                if (oComboBox.ValidValues.Count == 0)
                {
                    rsetValidValue.DoQuery(strQry);
                    rsetValidValue.MoveFirst();
                    for (int j = 0; j <= rsetValidValue.RecordCount - 1; j++)
                    {
                        oComboBox.ValidValues.Add(rsetValidValue.Fields.Item(0).Value, rsetValidValue.Fields.Item(1).Value);
                        rsetValidValue.MoveNext();
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("setComboBoxValue Function Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                return true;
            }
            finally
            {
            }

        }
        public int GetCodeGeneration(string TableName)
		{
			try {
				SAPbobsCOM.Recordset rsetCode = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
				string strCode = "Select IFNULL(Max(IFNULL(\"DocNum\",0)),0) + 1 Code From \"" + Strings.Trim(TableName) + "\"";
				rsetCode.DoQuery(strCode);
				return Convert.ToInt32(rsetCode.Fields.Item("Code").Value);
			} catch (Exception ex) {
				EventHandler.oApplication.StatusBar.SetText("GetCodeGeneration Function Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
				return -1;
			} finally {
			}
		}
		public int GetCodeGenerationMaster(string TableName)
		{
			try {
				SAPbobsCOM.Recordset rsetCode = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
				string strCode = "Select IFNULL(Max(IFNULL(\"Code\",0)),0) + 1 Code From \"" + Strings.Trim(TableName) + "\"";
				rsetCode.DoQuery(strCode);
				return Convert.ToInt32(rsetCode.Fields.Item("Code").Value);
			} catch (Exception ex) {
				EventHandler.oApplication.StatusBar.SetText("GetCodeGeneration Function Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
				return -1;
			} finally {
			}
		}
		public void SetNewLine(SAPbouiCOM.Matrix oMatrix, SAPbouiCOM.DBDataSource oDBDSDetail, int RowID = 1, string ColumnUID = "")
		{
			try {
				if (ColumnUID.Equals("") == false) {
					if (oMatrix.VisualRowCount > 0) {
						if (oMatrix.Columns.Item(ColumnUID).Cells.Item(RowID).Specific.Value.Equals("") == false & RowID == oMatrix.VisualRowCount) {
							oMatrix.FlushToDataSource();
							oMatrix.AddRow();
							oDBDSDetail.InsertRecord(oDBDSDetail.Size);
							oDBDSDetail.Offset = oMatrix.VisualRowCount - 1;
							oDBDSDetail.SetValue("LineID", oDBDSDetail.Offset, oMatrix.VisualRowCount.ToString());

							oMatrix.SetLineData(oMatrix.VisualRowCount);
							oMatrix.FlushToDataSource();
						}
					} else {
						oMatrix.FlushToDataSource();
						oMatrix.AddRow();
						oDBDSDetail.InsertRecord(oDBDSDetail.Size);
						oDBDSDetail.Offset = oMatrix.VisualRowCount - 1;
						oDBDSDetail.SetValue("LineID", oDBDSDetail.Offset, oMatrix.VisualRowCount.ToString());

						oMatrix.SetLineData(oMatrix.VisualRowCount);
						oMatrix.FlushToDataSource();
					}

				} else {
					oMatrix.FlushToDataSource();
					oMatrix.AddRow();
					oDBDSDetail.InsertRecord(oDBDSDetail.Size);
					oDBDSDetail.Offset = oMatrix.VisualRowCount - 1;
					oDBDSDetail.SetValue("LineID", oDBDSDetail.Offset, oMatrix.VisualRowCount.ToString());

					oMatrix.SetLineData(oMatrix.VisualRowCount);
					oMatrix.FlushToDataSource();
				}
			} catch (Exception ex) {
				EventHandler.oApplication.StatusBar.SetText("SetNewLine Method Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
			}
		}

        //For Item Filter Cfl
        public void choosefromlistItem(SAPbouiCOM.Form oForm,string cfLName,string Allies)
        {
            try
            {
                // Define your CFL object
                SAPbouiCOM.ChooseFromList oCFL = null;
                oCFL = oForm.ChooseFromLists.Item("CFL_itm"); // Replace "CFL_Item" with your CFL ID

                // Define your CFL conditions
                SAPbouiCOM.Condition oCond = null;
                oCond = oCFL.GetConditions().Add();
                oCond.Alias = "ItemCode"; // Replace "ItemClass" with the field name you want to filter
                oCond.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                oCond.CondVal = "I"; // Replace "I" with the value you want to filter by

                // Add additional condition for active items
                oCond = oCFL.GetConditions().Add();
                oCond.Alias = "ValidFor"; // Replace "ValidFor" with the field name that indicates item validity
                oCond.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                oCond.CondVal = "Y"; // Replace "Y" with the value that indicates item is active

                // Bind the CFL to the form
                oCFL.SetConditions(oCFL.GetConditions());
            }
            catch(Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("Choose FromList Item Filter Global Fun. Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
        }

        public void ChooseFromListFilteration(SAPbouiCOM.Form oForm, string strCFL_ID, string strCFL_Alies, string strQuery)
        {
            try
            {
                SAPbouiCOM.ChooseFromList oCFL = oForm.ChooseFromLists.Item(strCFL_ID);
                SAPbouiCOM.Conditions oConds = null;
                SAPbouiCOM.Condition oCond = null;
                SAPbouiCOM.Conditions oEmptyConds = new SAPbouiCOM.Conditions();
                SAPbobsCOM.Recordset rsetCFL = (SAPbobsCOM.Recordset)GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                oCFL.SetConditions(oEmptyConds);
                oConds = oCFL.GetConditions();

                rsetCFL.DoQuery(strQuery);
                rsetCFL.MoveFirst();
                for (int i = 1; i <= rsetCFL.RecordCount; i++)
                {
                    if (i == (rsetCFL.RecordCount))
                    {
                        oCond = oConds.Add();
                        oCond.Alias = strCFL_Alies;
                        oCond.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCond.CondVal = Strings.Trim(Convert.ToString(rsetCFL.Fields.Item(0).Value));
                    }
                    else
                    {
                        oCond = oConds.Add();
                        oCond.Alias = strCFL_Alies;
                        oCond.Operation = SAPbouiCOM.BoConditionOperation.co_EQUAL;
                        oCond.CondVal = Strings.Trim(Convert.ToString(rsetCFL.Fields.Item(0).Value));
                        oCond.Relationship = SAPbouiCOM.BoConditionRelationship.cr_OR;
                    }
                    rsetCFL.MoveNext();
                }
                if (rsetCFL.RecordCount == 0)
                {
                    oCond = oConds.Add();
                    oCond.Alias = strCFL_Alies;
                    oCond.Relationship = SAPbouiCOM.BoConditionRelationship.cr_NONE;
                    oCond.CondVal = "-1";
                }
                oCFL.SetConditions(oConds);
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("Choose FromList Filter Global Fun. Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
            finally
            {
            }
        }
        public void DeleteEmptyRowInFormDataEvent(SAPbouiCOM.Matrix oMatrix, string ColumnUID, SAPbouiCOM.DBDataSource oDBDSDetail)
		{
			try {
				if (oMatrix.VisualRowCount > 1) {
					int rows = oMatrix.RowCount;
					for (int i = 1; i <= rows - 1; i++) {
						if (oMatrix.Columns.Item(ColumnUID).Cells.Item(i).Specific.Value.Equals("")) {
							oMatrix.DeleteRow(i);
							oDBDSDetail.RemoveRecord(i - 1);
							oMatrix.FlushToDataSource();
							// rows -= 1
						}
					}
					if (oMatrix.Columns.Item(ColumnUID).Cells.Item(oMatrix.RowCount).Specific.Value.Equals("")) {
						oMatrix.DeleteRow(oMatrix.RowCount);
						oDBDSDetail.RemoveRecord(oMatrix.RowCount - 1);
						oMatrix.FlushToDataSource();
						// rows -= 1
					}
				} else if (oMatrix.VisualRowCount == 0) {
					GlobalVariables.oGFun.SetNewLine(oMatrix, oDBDSDetail);
				}
			} catch (Exception ex) {
				EventHandler.oApplication.StatusBar.SetText("Delete Empty RowIn Function Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
			} finally {
			}
		}
        public void DeleteEmptyRowInFormDataEventExportInvoice(SAPbouiCOM.Matrix oMatrix, string ColumnUID, string ColumnUID1, SAPbouiCOM.DBDataSource oDBDSDetail)
        {
            try
            {
                if (oMatrix.VisualRowCount > 1)
                {
                    int rows = oMatrix.RowCount;
                    for (int i = 1; i <= rows - 1; i++)
                    {
                        if (oMatrix.Columns.Item(ColumnUID).Cells.Item(i).Specific.Value.Equals("") && oMatrix.Columns.Item(ColumnUID1).Cells.Item(i).Specific.Value.Equals(""))
                        {
                            oMatrix.DeleteRow(i);
                            oDBDSDetail.RemoveRecord(i - 1);
                            oMatrix.FlushToDataSource();
                            // rows -= 1
                        }
                    }
                    if (oMatrix.Columns.Item(ColumnUID).Cells.Item(oMatrix.RowCount).Specific.Value.Equals("") && oMatrix.Columns.Item(ColumnUID1).Cells.Item(oMatrix.RowCount).Specific.Value.Equals(""))
                    {
                        oMatrix.DeleteRow(oMatrix.RowCount);
                        oDBDSDetail.RemoveRecord(oMatrix.RowCount - 1);
                        oMatrix.FlushToDataSource();
                        // rows -= 1
                    }
                }
                else if (oMatrix.VisualRowCount == 0)
                {
                    GlobalVariables.oGFun.SetNewLine(oMatrix, oDBDSDetail);
                }
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("Delete Empty RowIn Function Failed:" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
            finally
            {
            }
        }
        public void StatusBarErrorMsg(string ErrorMsg)
		{
			try {
				EventHandler.oApplication.StatusBar.SetText(ErrorMsg, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
			} catch (Exception ex) {
				EventHandler.oApplication.StatusBar.SetText("StatusBar ErrorMsg Method Failed" + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
			} finally {
			}
		}
        public void InsertDate(SAPbouiCOM.EditText date, DateTime DateTimeValue)
        {
            try
            {
                if (DateTimeValue > new DateTime(1920, 1, 1))
                {
                    date.Value = Convert.ToDateTime(DateTimeValue).ToString("yyyyMMdd");
                }
                else
                {
                    date.Value = "";
                }
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText(ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }
		#endregion

		#region "       Attachment Functions     "


		public class WindowWrapper : System.Windows.Forms.IWin32Window
		{

			private IntPtr _hwnd;
			public WindowWrapper(IntPtr handle)
			{
				_hwnd = handle;
			}

			public System.IntPtr Handle {
				get { return _hwnd; }
			}

		}



		#endregion

	}
}

