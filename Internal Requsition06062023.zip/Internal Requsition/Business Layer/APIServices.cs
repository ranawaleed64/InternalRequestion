﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LMS
{

    public class TokenGenration
    {
        public List<Class1> Property1 { get; set; }
    }

    public class Class1
    {
        public int id { get; set; }
        public string prefix { get; set; }
        public int tokenNumber { get; set; }
        public string contractorName { get; set; }
        public string contractorNic { get; set; }
        public string contractorNumber { get; set; }
        public string driverName { get; set; }
        public string driverNic { get; set; }
        public string driverNumber { get; set; }
        public string truckNumber { get; set; }
        public string dateIn { get; set; }
        public string dateOut { get; set; }
        public string timeIn { get; set; }
        public string timeOut { get; set; }
        public string createdBy { get; set; }
        public string updatedBy { get; set; }
        public string cAppStamp { get; set; }
        public string uAppStamp { get; set; }
        public string createDate { get; set; }
        public string updateDate { get; set; }
        public string completeTokenNumberUI { get; set; }
        public string message { get; set; }
    }
}
