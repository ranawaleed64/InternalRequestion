using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
namespace LMS
{
	public class TableCreation
	{
        #region TableCreation
        public TableCreation()
		{
            try
            {
                //this.GRPO();
                this.IR();
            }
            catch (Exception ex)
            {
                EventHandler.oApplication.StatusBar.SetText("Table Creation Failed: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
        }

        #region "Inernal"


        public void IR()
        {
            try
            {
                this.IRHeader();
                this.IRRows();
                if (!GlobalVariables.oGFun.UDOExists("OOIRT"))
                {
                    string[,] FindField = new string[,] { { "DocNum", "DocNum" }, { "CreateDate", "CreateDate" } };
                    GlobalVariables.oGFun.RegisterUDO("OOIRT", "Internal Req", SAPbobsCOM.BoUDOObjType.boud_Document, FindField, "AC_OIRT", "AC_IRT1");
                    FindField = null;
                }
            }
            catch (Exception ex)
            {

            }
        }
        //Dispatch Header
        public void IRHeader()
        {
            try
            {
                GlobalVariables.oGFun.CreateTable("AC_OIRT", "Internal Requestion", SAPbobsCOM.BoUTBTableType.bott_Document);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "EmpCode", "Emp Code ", SAPbobsCOM.BoFieldTypes.db_Alpha, 30);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "BisUn", "BisUnit", SAPbobsCOM.BoFieldTypes.db_Alpha, 30);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "Location", "Location", SAPbobsCOM.BoFieldTypes.db_Alpha, 30);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "EmpName", "Emp Name", SAPbobsCOM.BoFieldTypes.db_Alpha, 30);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "Dept", "Dept", SAPbobsCOM.BoFieldTypes.db_Alpha,30);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "Store", "Store ", SAPbobsCOM.BoFieldTypes.db_Alpha, 30);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "Status", "Status", SAPbobsCOM.BoFieldTypes.db_Alpha,50);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "Issuance", "Issuance", SAPbobsCOM.BoFieldTypes.db_Alpha,50);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "User", "UserName", SAPbobsCOM.BoFieldTypes.db_Alpha,50);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "DocType", "DocType", SAPbobsCOM.BoFieldTypes.db_Alpha,50);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "PDate", "PDate ", SAPbobsCOM.BoFieldTypes.db_Date);
                GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "CDate", "CDate ", SAPbobsCOM.BoFieldTypes.db_Date);

                // GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "WhsName", "WareHouseName ", SAPbobsCOM.BoFieldTypes.db_Alpha, 30);
                // GlobalVariables.oGFun.CreateUserFields("@AC_OIRT", "BinLoc", "BinLocation ", SAPbobsCOM.BoFieldTypes.db_Alpha, 30);

            }
            catch (Exception ex)
            {
            }
        }

        //Dispatch ChildTable
        public void IRRows()
        {
            try
            {
                GlobalVariables.oGFun.CreateTable("AC_IRT1", "Internal Req Rows", SAPbobsCOM.BoUTBTableType.bott_DocumentLines);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "ItemCode", "Item Code", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "ItemDesc", "Item Name", SAPbobsCOM.BoFieldTypes.db_Alpha, 200);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "UOM", "UOM", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "Qty", "Qty", SAPbobsCOM.BoFieldTypes.db_Float , 0, SAPbobsCOM.BoFldSubTypes.st_Quantity);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "Sum", "Sum", SAPbobsCOM.BoFieldTypes.db_Float , 0, SAPbobsCOM.BoFldSubTypes.st_Quantity);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "CStock", "CStock", SAPbobsCOM.BoFieldTypes.db_Float, 0,SAPbobsCOM.BoFldSubTypes.st_Quantity );
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "BusUnit", "BusUnit", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "BusUnitName", "BusUnitName", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "RDate", "RDate", SAPbobsCOM.BoFieldTypes.db_Date);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "Location", "Location", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "LocationName", "LocationName", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "Dept", "Dept", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "DeptName", "DeptName", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "CostC", "CostC", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "CostN", "CostN", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "Emp", "Emp", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "EmpName", "EmpName", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "Prj", "Prj", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "Reso", "Resource", SAPbobsCOM.BoFieldTypes.db_Alpha, 50);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "Status", "Status", SAPbobsCOM.BoFieldTypes.db_Alpha, 20);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "Descrpt", "Descrpt", SAPbobsCOM.BoFieldTypes.db_Alpha, 100);
                GlobalVariables.oGFun.CreateUserFields("@AC_IRT1", "Remark", "Remark", SAPbobsCOM.BoFieldTypes.db_Memo);

            }
            catch (Exception ex)
            {
                EventHandler.oApplication.MessageBox(ex.Message);
            }
        }

        #endregion


    }
    #endregion
}
