using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Xml;
using Newtonsoft.Json;
using System.Linq;

namespace LMS
{

    //' <summary>
    //' SAP has set of different events For access the controls.
    //' In this module particularly using to control events.
    //' 1) Menu Event using for while the User choose the menus to select the patricular form 
    //' 2) Item Event using for to pass the event Function while user doing process
    //' 3) Form Data Event Using to Insert,Update,Delete data on Date Base 
    //' 4) Status Bar Event will be call when display message to user, message may be will come 
    //'    Warring or Error
    //' </summary>
    //' <remarks></remarks>

    static class EventHandler
    {

        #region " ... Common Variables For SAP ..."
        private static SAPbouiCOM.Application withEventsField_oApplication;
        static string IrId = "";
        static string DocNum = "";
        public static SAPbouiCOM.Application oApplication
        {

            get { return withEventsField_oApplication; }
            //{ return oApplication; }
            set
            {
                if (withEventsField_oApplication != null)
                {
                    //  withEventsField_oApplication.LayoutKeyEvent -= oApplication_LayoutKeyEvent;
                    withEventsField_oApplication.MenuEvent -= oApplication_MenuEvent;
                    //withEventsField_oApplication.MenuEvent -= oApplication_MenuEvent1;
                    withEventsField_oApplication.AppEvent -= oApplication_AppEvent;
                    withEventsField_oApplication.ItemEvent -= oApplication_ItemEvent;
                    withEventsField_oApplication.FormDataEvent -= oApplication_FormDataEvent;
                    withEventsField_oApplication.StatusBarEvent -= oApplication_StatusBarEvent;
                    withEventsField_oApplication.RightClickEvent -= oApplication_RightClickEvent;
                }
                withEventsField_oApplication = value;
                if (withEventsField_oApplication != null)
                {
                    // withEventsField_oApplication.LayoutKeyEvent += oApplication_LayoutKeyEvent;
                    withEventsField_oApplication.MenuEvent += oApplication_MenuEvent;
                    //withEventsField_oApplication.MenuEvent += oApplication_MenuEvent1;
                    withEventsField_oApplication.AppEvent += oApplication_AppEvent;
                    withEventsField_oApplication.ItemEvent += oApplication_ItemEvent;
                    withEventsField_oApplication.FormDataEvent += oApplication_FormDataEvent;
                    withEventsField_oApplication.StatusBarEvent += oApplication_StatusBarEvent;
                    withEventsField_oApplication.RightClickEvent += oApplication_RightClickEvent;
                }
            }




        }
        #endregion


        #region " ... 1) Menu Event ..."
        private static void oApplication_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if ((pVal.BeforeAction == false))
                {

                    switch (pVal.MenuUID)
                    {
                        case "1282":
                        case "1281":
                        case "1292":
                        case "1293":
                        case "1287":
                        case "519":
                        case "1284":
                        case "1286":
                        case "1288":
                        case "1289":
                        case "1290":
                        case "1291":
                            //if (GlobalVariables.oForm.UniqueID == GlobalVariables.warehouseID)
                            //{
                            //    GlobalVariables.owarehouse.MenuEvent(ref pVal, out BubbleEvent);
                            //    break;
                            //}
                            if (GlobalVariables.oForm.UniqueID == "150")

                            {
                                //GlobalVariables.oItemMasterDataID.MenuEvent(ref pVal, out BubbleEvent);
                            }

                            else if (GlobalVariables.oForm.UniqueID == GlobalVariables.IRID)
                            {
                                GlobalVariables.ObjIR.MenuEvent(ref pVal, out BubbleEvent);
                                GC.Collect();
                                break;
                            }


                            break;
                    }
                }

                if ((pVal.BeforeAction == false))
                {

                    //LOAd IR
                    if (pVal.MenuUID == GlobalVariables.IRID)
                    {
                        if (GlobalVariables.oGFun.FormExist(GlobalVariables.IRID))
                        {
                            oApplication.Forms.Item(GlobalVariables.IRID).Visible = true;
                            oApplication.Forms.Item(GlobalVariables.IRID).Select();
                        }
                        else
                        {
                            GlobalVariables.ObjIR.LoadInternal();
                        }
                    }


                    GlobalVariables.oForm = oApplication.Forms.ActiveForm;
                    if ((pVal.MenuUID == "526"))
                    {
                        GlobalVariables.oCompany.Disconnect();
                        oApplication.StatusBar.SetText((GlobalVariables.addonName + " AddOn is DisConnected . . ."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(("Menu Event Failed : " + ex.Message), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);

            }
            finally
            {
            }
        }

        #endregion

        #region Application Events
        private static void oApplication_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            try
            {
                switch (EventType)
                {
                    case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                        System.Windows.Forms.Application.Exit();
                        break;
                }

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Application Event Failed: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
            finally
            {
            }

        }
        #endregion

        public static void CreateButton(ref SAPbouiCOM.ItemEvent pVal,string form)
        {
            try {


                GlobalVariables.oForm = EventHandler.oApplication.Forms.Item(pVal.FormUID);

                SAPbouiCOM.Button oButton;

                SAPbouiCOM.Item oItem;

                oItem = GlobalVariables.oForm.Items.Add("t_GetRec", SAPbouiCOM.BoFormItemTypes.it_BUTTON);

                SAPbouiCOM.Item sboItem2;

                if(form == "1470000200")

                {

                    sboItem2 = GlobalVariables.oForm.Items.Item("256000006");

                    oItem.Left = sboItem2.Left + sboItem2.Width + 5;

                    oItem.Top = sboItem2.Top;

                }


                if (form == "720")

                {
                    sboItem2 = GlobalVariables.oForm.Items.Item("256000002");

                    oItem.Left = sboItem2.Left + sboItem2.Width + 3;

                    oItem.Top = sboItem2.Top;

                    //oItem.Left = 500;

                    //oItem.Top = 40;

                }

                oItem.Width = 50;

                oItem.Height = 15;

                oButton = (SAPbouiCOM.Button)oItem.Specific;

                oButton.Caption = "Get Record";
            }
            catch(Exception ex)
            {
                oApplication.StatusBar.SetText(("Button Creation Failed : " + ex.Message + ex.StackTrace), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);

            }
        }

        public static void GetRecord()
        {
            SAPbouiCOM.Matrix oMatrix;
            try {
                //string Title = GlobalVariables.oForm.Title;
                // GlobalVariables.oForm.
                GlobalVariables.oForm = EventHandler.oApplication.Forms.ActiveForm;
                SAPbouiCOM.EditText oEdit = (SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("U_IRID").Specific);
                IrId = oEdit.Value;
                oEdit = (SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("7").Specific);
                DocNum = oEdit.Value.ToString();
                //oEdit = (SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("4").Specific);
                //string VendorCode = oEdit.Value;
                oMatrix = (SAPbouiCOM.Matrix)GlobalVariables.oForm.Items.Item("13").Specific;
                if (string.IsNullOrEmpty(IrId))
                {
                    oApplication.StatusBar.SetText(("Internal Requestion number or vendor cannot be empty...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    GlobalVariables.oForm.Items.Item("U_IRID").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                }
                else
                {
                    SAPbobsCOM.Recordset oRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    string ItemQury = string.Format("Select T0.[U_Store],T0.[U_Issuance],T1.[U_ItemCode],T1.[U_Qty],T1.[U_Sum],T1.[U_Location],T1.[U_Dept],T1.[U_CostC],T1.[U_Emp],T1.[U_BusUnit] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_ItemCode] IS NOT NULL and T0.[DocNum] = '" + IrId + "' and (T1.[U_Status] != 'C'  OR T1.[U_Status] IS NULL)").Replace("[", "\"").Replace("]", "\"");
                    oRecord.DoQuery(ItemQury);
                    GlobalVariables.oForm.Freeze(true);
                    string Issuance = Convert.ToString(oRecord.Fields.Item("U_Issuance").Value) ?? "";
                    string WhsCode = Convert.ToString(oRecord.Fields.Item("U_Store").Value) ?? "";
                    if (!string.IsNullOrEmpty(Issuance))
                    {
                        SAPbouiCOM.ComboBox ComboIssue = GlobalVariables.oForm.Items.Item("U_Issuance").Specific;
                        ComboIssue.Select(Issuance, SAPbouiCOM.BoSearchKey.psk_ByValue);
                        //(GlobalVariables.oForm.Items.Item("U_Issuance").Specific).Value = Issuance;
                    }
                    for (int i = 0; i < oRecord.RecordCount; i++)
                    {
                        string ItemCode = Convert.ToString(oRecord.Fields.Item("U_ItemCode").Value);
                        string Qty = Convert.ToString(oRecord.Fields.Item("U_Sum").Value);
                        string Loc = Convert.ToString(oRecord.Fields.Item("U_Location").Value) ?? "";
                        string Dept = Convert.ToString(oRecord.Fields.Item("U_Dept").Value) ?? "";
                        string CostCen = Convert.ToString(oRecord.Fields.Item("U_CostC").Value) ?? "";
                        string Emp = Convert.ToString(oRecord.Fields.Item("U_Emp").Value) ?? "";
                        string BusUnit = Convert.ToString(oRecord.Fields.Item("U_BusUnit").Value) ?? "";

                        ((SAPbouiCOM.EditText)oMatrix.Columns.Item("1").Cells.Item(i + 1).Specific).Value = ItemCode;
                        ((SAPbouiCOM.EditText)oMatrix.Columns.Item("9").Cells.Item(i + 1).Specific).Value = Qty;
                        ((SAPbouiCOM.EditText)oMatrix.Columns.Item("15").Cells.Item(i + 1).Specific).Value = WhsCode;
                        ((SAPbouiCOM.EditText)oMatrix.Columns.Item("10001004").Cells.Item(i + 1).Specific).Value = BusUnit;
                        ((SAPbouiCOM.EditText)oMatrix.Columns.Item("10001010").Cells.Item(i + 1).Specific).Value = Loc;
                        ((SAPbouiCOM.EditText)oMatrix.Columns.Item("10001012").Cells.Item(i + 1).Specific).Value = Dept;
                        ((SAPbouiCOM.EditText)oMatrix.Columns.Item("10001014").Cells.Item(i + 1).Specific).Value = CostCen;
                        ((SAPbouiCOM.EditText)oMatrix.Columns.Item("10001016").Cells.Item(i + 1).Specific).Value = Emp;
                        oRecord.MoveNext();
                    }

                    GlobalVariables.oForm.Freeze(false);
                }
            }
            catch(Exception ex)
            {
                oApplication.StatusBar.SetText(("Get Record Failed : " + ex.Message), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);

            }
        }

        //Get Record For PR
        public static void GetRecordPR()
        {

            SAPbouiCOM.Matrix oMatrix,oMatrixS;
            try
            {
                GlobalVariables.oForm = EventHandler.oApplication.Forms.ActiveForm;
                SAPbouiCOM.EditText oEdit = (SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("U_IRID").Specific);
                SAPbouiCOM.ComboBox oDoctype = (SAPbouiCOM.ComboBox)(GlobalVariables.oForm.Items.Item("3").Specific);
                string DocType = oDoctype.Value;

                IrId = oEdit.Value;
                oEdit = (SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("8").Specific);
                DocNum = oEdit.Value.ToString();
                //oEdit = (SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("4").Specific);
                //string VendorCode = oEdit.Value;
                oMatrix = (SAPbouiCOM.Matrix)GlobalVariables.oForm.Items.Item("38").Specific;
                oMatrixS = (SAPbouiCOM.Matrix)GlobalVariables.oForm.Items.Item("39").Specific;
                if (string.IsNullOrEmpty(IrId))
                {
                    oApplication.StatusBar.SetText(("Internal Requestion number or vendor cannot be empty...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
                    GlobalVariables.oForm.Items.Item("U_IRID").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                }
                else
                {
                    SAPbobsCOM.Recordset oRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);

                    string  DocTpeCheck = string.Format("Select T0.[U_DocType] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] where T0.[DocNum] = '"+ IrId + "'").Replace("[", "\"").Replace("]", "\"");
                    oRecord.DoQuery(DocTpeCheck);
                    string docTypeval = Convert.ToString(oRecord.Fields.Item("U_DocType").Value) ?? "";
                    if(docTypeval == DocType)
                    {
                        if(DocType == "I")
                        {
                            string ItemQury = string.Format("Select T0.[U_PDate],T1.[U_ItemCode],T1.[U_Qty],T1.[U_Location],T1.[U_Dept],T1.[U_CostC],T1.[U_Emp],T1.[U_BusUnit],T1.[U_Prj],T1.[U_RDate] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_ItemCode] IS NOT NULL and T0.[DocNum] = '" + IrId + "' and (T1.[U_Status] != 'C'  OR T1.[U_Status] IS NULL)").Replace("[", "\"").Replace("]", "\"");
                            oRecord.DoQuery(ItemQury);
                            GlobalVariables.oForm.Freeze(true);
                            DateTime RequirdDate = Convert.ToDateTime(oRecord.Fields.Item("U_PDate").Value) ?? "";
                            ((SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("540002106").Specific)).String = RequirdDate.ToString("dd.MM.yyyy"); 
                            oApplication.StatusBar.SetText(("Please wait... "), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                            for (int i = 0; i < oRecord.RecordCount; i++)
                            {
                                string ItemCode = Convert.ToString(oRecord.Fields.Item("U_ItemCode").Value);
                                string Qty = Convert.ToString(oRecord.Fields.Item("U_Qty").Value);
                                string Loc = Convert.ToString(oRecord.Fields.Item("U_Location").Value) ?? "";
                                string Dept = Convert.ToString(oRecord.Fields.Item("U_Dept").Value) ?? "";
                                string CostCen = Convert.ToString(oRecord.Fields.Item("U_CostC").Value) ?? "";
                                string Emp = Convert.ToString(oRecord.Fields.Item("U_Emp").Value) ?? "";
                                string BusUnit = Convert.ToString(oRecord.Fields.Item("U_BusUnit").Value) ?? "";
                                string Project = Convert.ToString(oRecord.Fields.Item("U_Prj").Value) ?? "";
                                DateTime RDate = Convert.ToDateTime(oRecord.Fields.Item("U_RDate").Value) ?? "";

                                ((SAPbouiCOM.EditText)oMatrix.Columns.Item("1").Cells.Item(i + 1).Specific).Value = ItemCode;
                                ((SAPbouiCOM.EditText)oMatrix.Columns.Item("11").Cells.Item(i + 1).Specific).Value = Qty;
                                ((SAPbouiCOM.EditText)oMatrix.Columns.Item("2004").Cells.Item(i + 1).Specific).Value = BusUnit;
                                ((SAPbouiCOM.EditText)oMatrix.Columns.Item("2003").Cells.Item(i + 1).Specific).Value = Loc;
                                ((SAPbouiCOM.EditText)oMatrix.Columns.Item("2002").Cells.Item(i + 1).Specific).Value = Dept;
                                ((SAPbouiCOM.EditText)oMatrix.Columns.Item("2001").Cells.Item(i + 1).Specific).Value = CostCen;
                                ((SAPbouiCOM.EditText)oMatrix.Columns.Item("2000").Cells.Item(i + 1).Specific).Value = Emp;
                                string dat = RDate.ToString("dd.MM.yyyy");
                                ((SAPbouiCOM.EditText)oMatrix.Columns.Item("540002123").Cells.Item(i + 1).Specific).String = RDate.ToString("dd.MM.yyyy");
                                ((SAPbouiCOM.EditText)oMatrix.Columns.Item("31").Cells.Item(i + 1).Specific).Value = Project;
                                oRecord.MoveNext();
                            }
                        }
                        oApplication.StatusBar.SetText(("Items Imoprt  Successfully... "), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        GlobalVariables.oForm.Freeze(false);

                        if (DocType == "S")
                        {
                            string ItemQury = string.Format("Select [U_PDate],T1.[U_Descrpt],T1.[U_Location],T1.[U_Dept],T1.[U_RDate],T1.[U_CostC],T1.[U_Emp],T1.[U_BusUnit],T1.[U_Prj]  from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_Descrpt] IS NOT NULL and T0.[DocNum] = '" + IrId + "' and (T1.[U_Status] != 'C'  OR T1.[U_Status] IS NULL)").Replace("[", "\"").Replace("]", "\"");
                            oRecord.DoQuery(ItemQury);
                            DateTime RequirdDate = Convert.ToDateTime(oRecord.Fields.Item("U_PDate").Value) ?? "";
                            ((SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("540002106").Specific)).String = RequirdDate.ToString("dd.MM.yyyy");
                            for (int j = 0; j < oRecord.RecordCount; j++)
                            {
                                string Details = Convert.ToString(oRecord.Fields.Item("U_Descrpt").Value);
                                string Loc = Convert.ToString(oRecord.Fields.Item("U_Location").Value) ?? "";
                                string Dept = Convert.ToString(oRecord.Fields.Item("U_Dept").Value) ?? "";
                                string CostCen = Convert.ToString(oRecord.Fields.Item("U_CostC").Value) ?? "";
                                string Emp = Convert.ToString(oRecord.Fields.Item("U_Emp").Value) ?? "";
                                string BusUnit = Convert.ToString(oRecord.Fields.Item("U_BusUnit").Value) ?? "";
                                string Project = Convert.ToString(oRecord.Fields.Item("U_Prj").Value) ?? "";
                                DateTime RDate = Convert.ToDateTime(oRecord.Fields.Item("U_RDate").Value) ?? "";
                                ((SAPbouiCOM.EditText)oMatrixS.Columns.Item("1").Cells.Item(j + 1).Specific).Value = Details;
                                ((SAPbouiCOM.EditText)oMatrixS.Columns.Item("540002066").Cells.Item(j + 1).Specific).String = RDate.ToString("dd.MM.yyyy");
                                ((SAPbouiCOM.EditText)oMatrixS.Columns.Item("2004").Cells.Item(j + 1).Specific).Value = BusUnit;
                                ((SAPbouiCOM.EditText)oMatrixS.Columns.Item("2003").Cells.Item(j + 1).Specific).Value = Loc;
                                ((SAPbouiCOM.EditText)oMatrixS.Columns.Item("2002").Cells.Item(j + 1).Specific).Value = Dept;
                                ((SAPbouiCOM.EditText)oMatrixS.Columns.Item("2001").Cells.Item(j + 1).Specific).Value = CostCen;
                                ((SAPbouiCOM.EditText)oMatrixS.Columns.Item("2000").Cells.Item(j + 1).Specific).Value = Emp;
                                oRecord.MoveNext();
                            }
                        }
                    }
                    else
                    {
                        System.Media.SystemSounds.Asterisk.Play();
                        oApplication.StatusBar.SetText(("Kindly change Doc Type .... "), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
                        GlobalVariables.oForm.Items.Item("3").Click(SAPbouiCOM.BoCellClickType.ct_Regular);
                    }
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(("Get Record Failed : " + ex.Message), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
        }

        #region " ... 2) Item Event ..."
        private static void oApplication_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {

            BubbleEvent = true;

            //GlobalVariables.oForm = EventHandler.oApplication.Forms.ActiveForm;
            try
            {
                if (pVal.FormType == 720   && pVal.BeforeAction == false) 
                { 
                    switch (pVal.EventType)
                    {
                        case SAPbouiCOM.BoEventTypes.et_FORM_LOAD:
                            CreateButton(ref pVal,"720");
                            break;
                        case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED:
                            if(pVal.ItemUID == "t_GetRec" && pVal.BeforeAction == false)
                            {
                                GetRecord();
                            }
                            break;
                    }
            }

                //PR  

                if (pVal.FormType == 1470000200 && pVal.BeforeAction == false)
                {
                    switch (pVal.EventType)
                    {
                        case SAPbouiCOM.BoEventTypes.et_FORM_LOAD:
                            CreateButton(ref pVal, "1470000200");
                            break;
                        case SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED:
                            if (pVal.ItemUID == "t_GetRec" && pVal.BeforeAction == false)
                            {
                                GetRecordPR();
                            }
                            break;
                    }
                }

                //Post Po


                #region "Purchase Order"

                if (pVal.FormType == 142 && pVal.ItemUID == "1" && pVal.EventType == SAPbouiCOM.BoEventTypes.et_ITEM_PRESSED && pVal.BeforeAction == false)
                {
                    GlobalVariables.oForm = EventHandler.oApplication.Forms.Item(pVal.FormUID);
                    //GlobalVariables.oForm = EventHandler.oApplication.Forms.ActiveForm;
                    SAPbouiCOM.ComboBox oDoctype = (SAPbouiCOM.ComboBox)(GlobalVariables.oForm.Items.Item("3").Specific);
                    string DocType = oDoctype.Value;
                    if (GlobalVariables.oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE && pVal.BeforeAction == false)
                    {
                        SAPbobsCOM.Recordset oRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        SAPbobsCOM.Recordset oRecordIssue = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        SAPbobsCOM.Recordset oRecUpdate = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                        SAPbouiCOM.EditText oEdit = (SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("U_IRID").Specific);
                        string internalId = oEdit.Value;
                        if (!string.IsNullOrEmpty(IrId))
                        {
                            if(DocType == "S")
                            {
                                string UpdateMain = "";
                                string ItemQury = string.Format("Select T1.[U_Descrpt],T0.[DocEntry] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_Descrpt] IS NOT NULL and T0.[DocNum] = '" + IrId + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecord.DoQuery(ItemQury);
                                string DocEntry = Convert.ToString(oRecord.Fields.Item("DocEntry").Value);
                                string GoodIssue = string.Format("Select T1.[Dscription] from OPRQ T0  INNER JOIN PRQ1 T1 ON T0.[DocEntry] = T1.[DocEntry] where T0.[DocNum] = '" + DocNum + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecordIssue.DoQuery(GoodIssue);
                                for (int i = 0; i < oRecordIssue.RecordCount; i++)
                                {
                                    string ItemCode = Convert.ToString(oRecordIssue.Fields.Item("Dscription").Value);
                                    string UpdateStat = string.Format("Update T0 set T0.[U_Status] = 'PM' from [@AC_IRT1] T0 where T0.[U_Descrpt] = '" + ItemCode + "' and T0.[DocEntry] = '" + DocEntry + "'").Replace("[", "\"").Replace("]", "\"");
                                    oRecUpdate.DoQuery(UpdateStat);
                                    oRecordIssue.MoveNext();
                                }
                                UpdateMain = string.Format("Update T0 set T0.[U_Status] = 'O' from [@AC_OIRT] T0 where T0.[DocNum] = '" + IrId + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecUpdate.DoQuery(UpdateMain);
                                oApplication.StatusBar.SetText(("Status Is changed in Internal Requestion...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                            }

                            if (DocType == "I")
                            {
                                string UpdateMain = "";
                                string ItemQury = string.Format("Select T1.[U_ItemCode],T0.[DocEntry] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_ItemCode] IS NOT NULL and T0.[DocNum] = '" + IrId + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecord.DoQuery(ItemQury);
                                string DocEntry = Convert.ToString(oRecord.Fields.Item("DocEntry").Value);
                                string GoodIssue = string.Format("Select T1.[ItemCode],T1.[Quantity] from OPRQ T0  INNER JOIN PRQ1 T1 ON T0.[DocEntry] = T1.[DocEntry] where T0.[DocNum] = '" + DocNum + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecordIssue.DoQuery(GoodIssue);
                                for (int i = 0; i < oRecordIssue.RecordCount; i++)
                                {
                                    string ItemCode = Convert.ToString(oRecordIssue.Fields.Item("ItemCode").Value);
                                    string UpdateStat = string.Format("Update T0 set T0.[U_Status] = 'PM' from [@AC_IRT1] T0 where T0.[U_ItemCode] = '" + ItemCode + "' and T0.[DocEntry] = '" + DocEntry + "'").Replace("[", "\"").Replace("]", "\"");
                                    oRecUpdate.DoQuery(UpdateStat);
                                    oRecordIssue.MoveNext();
                                }
                                UpdateMain = string.Format("Update T0 set T0.[U_Status] = 'O' from [@AC_OIRT] T0 where T0.[DocNum] = '" + IrId + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecUpdate.DoQuery(UpdateMain);
                                oApplication.StatusBar.SetText(("Status Is changed in Internal Requestion...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                            }
                        }
                    }
                    string formMode = GlobalVariables.oForm.Mode.ToString();
                }
                #endregion

                else if (pVal.FormUID == GlobalVariables.IRID)
                {
                    GlobalVariables.ObjIR.ItemEvent(GlobalVariables.IRID, ref pVal, out BubbleEvent);
                }
            }

            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(("Item Event Failed : " + ex.Message), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
            finally
            {
            }
        }
        #endregion

        #region " ... 3) FormDataEvent ..."
        private static void oApplication_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                //GRPO Form 
                GlobalVariables.oForm = EventHandler.oApplication.Forms.ActiveForm;
                if (BusinessObjectInfo.FormTypeEx == "720" && GlobalVariables.oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE   && BusinessObjectInfo.BeforeAction == false && BusinessObjectInfo.ActionSuccess == true)
                {
                    SAPbobsCOM.Recordset oRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    SAPbobsCOM.Recordset oRecordIssue = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    SAPbobsCOM.Recordset oRecUpdate = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    SAPbobsCOM.Recordset oRecordIRquantity = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    if (!string.IsNullOrEmpty(IrId))
                    {
                        string ItemQury = string.Format("Select T1.[U_ItemCode],T0.[DocEntry] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_ItemCode] IS NOT NULL and T0.[DocNum] = '" + IrId + "'").Replace("[", "\"").Replace("]", "\"");
                        oRecord.DoQuery(ItemQury);
                        string DocEntry = Convert.ToString(oRecord.Fields.Item("DocEntry").Value);
                        string GoodIssue = string.Format("Select T1.[ItemCode],T1.[Quantity] from OIGE T0  INNER JOIN IGE1 T1 ON T0.[DocEntry] = T1.[DocEntry] where T0.[DocNum] = '" + DocNum + "'").Replace("[", "\"").Replace("]", "\"");
                        oRecordIssue.DoQuery(GoodIssue);
                        for (int i = 0; i < oRecordIssue.RecordCount; i++)
                        {
                            string ItemCode = Convert.ToString(oRecordIssue.Fields.Item("ItemCode").Value);
                            double Quantity = Convert.ToDouble(oRecordIssue.Fields.Item("Quantity").Value);
                            string IRQuantityQry = string.Format("Select T1.[U_Sum],T0.[DocEntry] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where  T1.[U_ItemCode] = '" + ItemCode + "' and T0.[DocEntry] = '" + DocEntry + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecordIRquantity.DoQuery(IRQuantityQry);
                            double IRQuanty = Convert.ToDouble(oRecordIRquantity.Fields.Item("U_Sum").Value);
                            double RemainingQanty = IRQuanty - Quantity;
                            string UpdateOpemQanty = string.Format("Update T0 set T0.[U_Sum] = '"+ RemainingQanty + "' from [@AC_IRT1] T0 where T0.[U_ItemCode] = '" + ItemCode + "' and T0.[DocEntry] = '" + DocEntry + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecUpdate.DoQuery(UpdateOpemQanty);
                            if(RemainingQanty == 0)
                            {
                                string UpdateStat = string.Format("Update T0 set T0.[U_Status] = 'C' from [@AC_IRT1] T0 where T0.[U_ItemCode] = '" + ItemCode + "' and T0.[DocEntry] = '" + DocEntry + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecUpdate.DoQuery(UpdateStat);
                            }
                            oRecordIssue.MoveNext();
                            if (i == 0)
                            {
                                oApplication.StatusBar.SetText(("Status Is changed in Internal Requestion...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                            }
                        }
                        string closeCheck = string.Format("Select Count(*) Cnt from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry]   Where T1.[U_ItemCode]   IS NOT NULL and T0.[DocNum] = '"+IrId+"' and   T1.[U_Status] = 'C' ").Replace("[", "\"").Replace("]","\"");
                        oRecordIssue.DoQuery(closeCheck);
                        int closCnt = Convert.ToInt32(oRecordIssue.Fields.Item("Cnt").Value);
                        closeCheck = string.Format("Select Count(*) AllCnt from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry]   Where T1.[U_ItemCode]   IS NOT NULL and T0.[DocNum] = '" + IrId + "' ").Replace("[", "\"").Replace("]", "\"");
                        oRecordIssue.DoQuery(closeCheck);
                        int TotCnt = Convert.ToInt32(oRecordIssue.Fields.Item("AllCnt").Value);
                        if(closCnt == TotCnt)
                        {
                            string UpdateHead = string.Format("Update T0 set T0.[U_Status] = 'C' from [@AC_OIRT] T0 where  T0.[DocNum] = '" + IrId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecordIssue.DoQuery(UpdateHead);
                        }
                    }
                }

                //PR Adding 

                if (BusinessObjectInfo.FormTypeEx == "1470000200" && GlobalVariables.oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE && BusinessObjectInfo.BeforeAction == false && BusinessObjectInfo.ActionSuccess == true)
                {
                    SAPbouiCOM.ComboBox oDoctype = (SAPbouiCOM.ComboBox)(GlobalVariables.oForm.Items.Item("3").Specific);
                    string DocType = oDoctype.Value;

                    SAPbobsCOM.Recordset oRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    SAPbobsCOM.Recordset oRecordIssue = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    SAPbobsCOM.Recordset oRecUpdate = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    if (!string.IsNullOrEmpty(IrId))
                    {
                        if(DocType == "S")
                        {
                            string UpdateMain = "";
                            string ItemQury = string.Format("Select T1.[U_Descrpt],T0.[DocEntry] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_ItemCode] IS NOT NULL and T0.[DocNum] = '" + IrId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecord.DoQuery(ItemQury);
                            string DocEntry = Convert.ToString(oRecord.Fields.Item("DocEntry").Value);
                            string GoodIssue = string.Format("Select T1.[Dscription] from OPRQ T0  INNER JOIN PRQ1 T1 ON T0.[DocEntry] = T1.[DocEntry] where T0.[DocNum] = '" + DocNum + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecordIssue.DoQuery(GoodIssue);

                            for (int i = 0; i < oRecordIssue.RecordCount; i++)
                            {
                                string ItemCode = Convert.ToString(oRecordIssue.Fields.Item("Dscription").Value);
                                string UpdateStat = string.Format("Update T0 set T0.[U_Status] = 'PR' from [@AC_IRT1] T0 where T0.[U_Descrpt] = '" + ItemCode + "' and T0.[DocEntry] = '" + DocEntry + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecUpdate.DoQuery(UpdateStat);
                                oRecordIssue.MoveNext();
                                if (i == 0)
                                {
                                    oApplication.StatusBar.SetText(("Status Is changed in Internal Requestion...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                                }
                            }
                            UpdateMain = string.Format("Update T0 set T0.[U_Status] = 'O' from [@AC_OIRT] T0 where T0.[DocNum] = '" + IrId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecUpdate.DoQuery(UpdateMain);
                            oApplication.StatusBar.SetText(("Status Is changed in Internal Requestion...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);

                        }

                        if (DocType == "I")
                        {
                            string UpdateMain = "";
                            string ItemQury = string.Format("Select T1.[U_ItemCode],T0.[DocEntry] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_ItemCode] IS NOT NULL and T0.[DocNum] = '" + IrId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecord.DoQuery(ItemQury);
                            string DocEntry = Convert.ToString(oRecord.Fields.Item("DocEntry").Value);
                            string GoodIssue = string.Format("Select T1.[ItemCode],T1.[Quantity] from OPRQ T0  INNER JOIN PRQ1 T1 ON T0.[DocEntry] = T1.[DocEntry] where T0.[DocNum] = '" + DocNum + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecordIssue.DoQuery(GoodIssue);

                            for (int i = 0; i < oRecordIssue.RecordCount; i++)
                            {
                                string ItemCode = Convert.ToString(oRecordIssue.Fields.Item("ItemCode").Value);
                                string UpdateStat = string.Format("Update T0 set T0.[U_Status] = 'PR' from [@AC_IRT1] T0 where T0.[U_ItemCode] = '" + ItemCode + "' and T0.[DocEntry] = '" + DocEntry + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecUpdate.DoQuery(UpdateStat);
                                oRecordIssue.MoveNext();
                                if(i == 0)
                                {
                                    oApplication.StatusBar.SetText(("Status Is changed in Internal Requestion...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);

                                }
                            }
                            UpdateMain = string.Format("Update T0 set T0.[U_Status] = 'O' from [@AC_OIRT] T0 where T0.[DocNum] = '" + IrId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecUpdate.DoQuery(UpdateMain);

                        }
                    }
                }


                //PO Form

                if (BusinessObjectInfo.FormTypeEx == "142" && GlobalVariables.oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE  && BusinessObjectInfo.BeforeAction == false && BusinessObjectInfo.ActionSuccess == true)
                {
                    //GlobalVariables.oForm = EventHandler.oApplication.Forms.ActiveForm;
                    SAPbouiCOM.ComboBox oDoctype = (SAPbouiCOM.ComboBox)(GlobalVariables.oForm.Items.Item("3").Specific);
                    string DocType = oDoctype.Value;
                    SAPbobsCOM.Recordset oRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    SAPbobsCOM.Recordset oRecordIssue = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    SAPbobsCOM.Recordset oRecUpdate = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    SAPbouiCOM.EditText oEdit = (SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("U_IRID").Specific);
                    string internalId = oEdit.Value;
                    oEdit = (SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("8").Specific);
                    DocNum = oEdit.Value;
                    if (!string.IsNullOrEmpty(internalId))
                    {
                        if (DocType == "S")
                        {
                            string UpdateMain = "";
                            string ItemQury = string.Format("Select T1.[U_Descrpt],T0.[DocEntry] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_Descrpt] IS NOT NULL and T0.[DocNum] = '" + internalId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecord.DoQuery(ItemQury);
                            string DocEntry = Convert.ToString(oRecord.Fields.Item("DocEntry").Value);
                            string GoodIssue = string.Format("Select T1.[Dscription] from OPOR T0  INNER JOIN POR1 T1 ON T0.[DocEntry] = T1.[DocEntry] where T0.[DocNum] = '" + DocNum + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecordIssue.DoQuery(GoodIssue);
                            for (int i = 0; i < oRecordIssue.RecordCount; i++)
                            {
                                string ItemCode = Convert.ToString(oRecordIssue.Fields.Item("Dscription").Value);
                                string UpdateStat = string.Format("Update T0 set T0.[U_Status] = 'PM' from [@AC_IRT1] T0 where T0.[U_Descrpt] = '" + ItemCode + "' and T0.[DocEntry] = '" + DocEntry + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecUpdate.DoQuery(UpdateStat);
                                oRecordIssue.MoveNext();
                            }
                            UpdateMain = string.Format("Update T0 set T0.[U_Status] = 'O' from [@AC_OIRT] T0 where T0.[DocNum] = '" + internalId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecUpdate.DoQuery(UpdateMain);
                            oApplication.StatusBar.SetText(("Status Is changed in Internal Requestion...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        }

                        if (DocType == "I")
                        {
                            string UpdateMain = "";
                            string ItemQury = string.Format("Select T1.[U_ItemCode],T0.[DocEntry] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_ItemCode] IS NOT NULL and T0.[DocNum] = '" + internalId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecord.DoQuery(ItemQury);
                            string DocEntry = Convert.ToString(oRecord.Fields.Item("DocEntry").Value);
                            string GoodIssue = string.Format("Select T1.[ItemCode],T1.[Quantity] from OPOR T0  INNER JOIN POR1 T1 ON T0.[DocEntry] = T1.[DocEntry] where T0.[DocNum] = '" + DocNum + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecordIssue.DoQuery(GoodIssue);
                            for (int i = 0; i < oRecordIssue.RecordCount; i++)
                            {
                                string ItemCode = Convert.ToString(oRecordIssue.Fields.Item("ItemCode").Value);
                                string UpdateStat = string.Format("Update T0 set T0.[U_Status] = 'PM' from [@AC_IRT1] T0 where T0.[U_ItemCode] = '" + ItemCode + "' and T0.[DocEntry] = '" + DocEntry + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecUpdate.DoQuery(UpdateStat);
                                oRecordIssue.MoveNext();
                            }
                            UpdateMain = string.Format("Update T0 set T0.[U_Status] = 'O' from [@AC_OIRT] T0 where T0.[DocNum] = '" + internalId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecUpdate.DoQuery(UpdateMain);
                            oApplication.StatusBar.SetText(("Status Is changed in Internal Requestion...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        }
                    }
                }

                //GRPO

                if (BusinessObjectInfo.FormTypeEx == "143" && GlobalVariables.oForm.Mode == SAPbouiCOM.BoFormMode.fm_ADD_MODE && BusinessObjectInfo.BeforeAction == false && BusinessObjectInfo.ActionSuccess == true )
                {
                    GlobalVariables.oForm = EventHandler.oApplication.Forms.ActiveForm;
                    //string DocT = ((SAPbouiCOM.ComboBox)(GlobalVariables.oForm.Items.Item("3").Specific)).Value;
                    SAPbouiCOM.ComboBox oDoctype = (SAPbouiCOM.ComboBox)GlobalVariables.oForm.Items.Item("3").Specific;
                    string DocType = oDoctype.Value;
                    SAPbobsCOM.Recordset oRecord = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    SAPbobsCOM.Recordset oRecordIssue = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    SAPbobsCOM.Recordset oRecUpdate = GlobalVariables.oCompany.GetBusinessObject(SAPbobsCOM.BoObjectTypes.BoRecordset);
                    SAPbouiCOM.EditText oEdit = (SAPbouiCOM.EditText)(GlobalVariables.oForm.Items.Item("U_IRID").Specific);
                    string internalId = oEdit.Value;
                    oEdit = (SAPbouiCOM.EditText)GlobalVariables.oForm.Items.Item("8").Specific;
                    DocNum = oEdit.Value;
                    if (!string.IsNullOrEmpty(internalId))
                    {
                        if (DocType == "S")
                        {
                            string UpdateMain = "";
                            string ItemQury = string.Format("Select T1.[U_Descrpt],T0.[DocEntry] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_Descrpt] IS NOT NULL and T0.[DocNum] = '" + internalId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecord.DoQuery(ItemQury);
                            string DocEntry = Convert.ToString(oRecord.Fields.Item("DocEntry").Value);
                            string GoodIssue = string.Format("Select T1.[Dscription] from OPDN T0  INNER JOIN PDN1 T1 ON T0.[DocEntry] = T1.[DocEntry] where T0.[DocNum] = '" + DocNum + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecordIssue.DoQuery(GoodIssue);
                            for (int i = 0; i < oRecordIssue.RecordCount; i++)
                            {
                                string ItemCode = Convert.ToString(oRecordIssue.Fields.Item("Dscription").Value);
                                string UpdateStat = string.Format("Update T0 set T0.[U_Status] = 'PC' from [@AC_IRT1] T0 where T0.[U_Descrpt] = '" + ItemCode + "' and T0.[DocEntry] = '" + DocEntry + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecUpdate.DoQuery(UpdateStat);
                                oRecordIssue.MoveNext();
                            }
                            UpdateMain = string.Format("Update T0 set T0.[U_Status] = 'O' from [@AC_OIRT] T0 where T0.[DocNum] = '" + internalId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecUpdate.DoQuery(UpdateMain);
                            oApplication.StatusBar.SetText(("Status Is changed in Internal Requestion...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        }

                        if (DocType == "I")
                        {
                            string UpdateMain = "";
                            string ItemQury = string.Format("Select T1.[U_ItemCode],T0.[DocEntry] from [@AC_OIRT] T0 Inner join [@AC_IRT1] T1 on T0.[DocEntry] = T1.[DocEntry] Where T1.[U_ItemCode] IS NOT NULL and T0.[DocNum] = '" + internalId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecord.DoQuery(ItemQury);
                            string DocEntry = Convert.ToString(oRecord.Fields.Item("DocEntry").Value);
                            string GoodIssue = string.Format("Select T1.[ItemCode],T1.[Quantity] from OPDN T0  INNER JOIN PDN1 T1 ON T0.[DocEntry] = T1.[DocEntry] where T0.[DocNum] = '" + DocNum + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecordIssue.DoQuery(GoodIssue);
                            for (int i = 0; i < oRecordIssue.RecordCount; i++)
                            {
                                string ItemCode = Convert.ToString(oRecordIssue.Fields.Item("ItemCode").Value);
                                string UpdateStat = string.Format("Update T0 set T0.[U_Status] = 'PC' from [@AC_IRT1] T0 where T0.[U_ItemCode] = '" + ItemCode + "' and T0.[DocEntry] = '" + DocEntry + "'").Replace("[", "\"").Replace("]", "\"");
                                oRecUpdate.DoQuery(UpdateStat);
                                oRecordIssue.MoveNext();
                            }
                            UpdateMain = string.Format("Update T0 set T0.[U_Status] = 'O' from [@AC_OIRT] T0 where T0.[DocNum] = '" + internalId + "'").Replace("[", "\"").Replace("]", "\"");
                            oRecUpdate.DoQuery(UpdateMain);
                            oApplication.StatusBar.SetText(("Status Is changed in Internal Requestion...."), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Success);
                        }
                    }
                }


                if (BusinessObjectInfo.FormUID == GlobalVariables.IRID)
                {
                    GlobalVariables.ObjIR.FormDataEvent(ref BusinessObjectInfo, ref BubbleEvent);
                }

            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(("Form DataEvent Failed : " + ex.Message), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
            finally
            {
            }
        }

        #endregion

        #region " ... 4) Status Bar Event ..."
        public static void oApplication_StatusBarEvent(string Text, SAPbouiCOM.BoStatusBarMessageType MessageType)
        {
            try
            {
                if (MessageType == SAPbouiCOM.BoStatusBarMessageType.smt_Warning | MessageType == SAPbouiCOM.BoStatusBarMessageType.smt_Error)
                {
                    System.Media.SystemSounds.Asterisk.Play();
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(GlobalVariables.addonName + " StatusBarEvent Event Failed : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
            finally
            {
            }
        }

        #endregion

        #region " ... 5) Set Event Filter ..."
        public static void SetEventFilter()
        {
            try
            {
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText(ex.Message);
            }
            finally
            {
            }
        }
        #endregion

        #region " ... 6) Right Click Event ..."
        private static void oApplication_RightClickEvent(ref SAPbouiCOM.ContextMenuInfo eventInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (eventInfo.FormUID == GlobalVariables.IRID)
                {
                    GlobalVariables.ObjIR.RightClickEvent(ref eventInfo, ref BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText((GlobalVariables.addonName + (" : Right Click Event Failed : " + ex.Message)), SAPbouiCOM.BoMessageTime.bmt_Medium, SAPbouiCOM.BoStatusBarMessageType.smt_Warning);
            }
            finally
            {
            }
        }
        #endregion


    }
}
