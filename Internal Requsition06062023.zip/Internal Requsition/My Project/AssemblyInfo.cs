using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

// Review the values of the assembly attributes

[assembly: AssemblyTitle("LMS")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyCompany("IESPL")]
[assembly: AssemblyProduct("LMS")]
[assembly: AssemblyCopyright("Copyright © Abacus 2011")]

[assembly: AssemblyTrademark("")]

[assembly: ComVisible(false)]
//The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("599013a5-69a7-4f0f-b067-36d175f8d2f6")]
// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// <Assembly: AssemblyVersion("1.0.*")> 

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
